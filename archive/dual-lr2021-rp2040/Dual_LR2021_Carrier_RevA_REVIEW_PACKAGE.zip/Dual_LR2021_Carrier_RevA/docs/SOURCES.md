# Source register

Accessed 2026-10-13. URLs are references, not bundled manufacturer intellectual property.

## S1 - Waveshare Core2021-XF documentation / exact HF-M SKU
https://docs.waveshare.com/Core2021-XF

## S2 - Radio underside labels (mirror horizontally for top view)
https://docs.waveshare.com/assets/images/Core2021-HF-Product-introduce-02-8055d4bcd0081527f6cc924f00d8c3b0.webp

## S3 - Radio dimensional image (shared family drawing; independently verify HF-M)
https://docs.waveshare.com/assets/images/Core2021-HF-Product-introduce-03-9592b4d1100c62739ad133b74507ebfc.webp

## S4 - Waveshare RP2040-Plus / -M documentation
https://docs.waveshare.com/RP2040-Plus

## S5 - RP2040-Plus dimensional drawing
https://docs.waveshare.com/assets/images/RP2040-Plus-details-size-6c1430864c01e95cbf22c9d4c128e82c.webp

## S6 - RP2040-Plus linked schematic (TPS63000 version)
https://files.waveshare.com/wiki/RP2040-Plus/RP2040_Plus.pdf

## S7 - TI TPS22919 datasheet and DCK0006A land pattern
https://www.ti.com/lit/ds/symlink/tps22919.pdf

## S8 - Samtec SSW through-hole recommended footprint
https://suddendocs.samtec.com/prints/ssw-s.pdf

## S9 - Samtec SSW series mechanical print
https://suddendocs.samtec.com/prints/ssw-1xx-xx-xxx-x-xx-xxx-xx-mkt.pdf

## S10 - JLCPCB PCBA scope / through-hole assembly FAQ (not an acceptance or quote)
https://jlcpcb.com/help/article/pcb-assembly-faqs

## S11 - KiCad board S-expression format
https://dev-docs.kicad.org/en/file-formats/sexpr-pcb/

## S12 - KiCad schematic S-expression format
https://dev-docs.kicad.org/en/file-formats/sexpr-schematic/

## S13 - Semtech LR2021 datasheet copy, typical TX current reference
https://www.mouser.com/pdfDocs/61979758LR2021_V1_1_datasheet.pdf

## S14 - TDK CGA4J3X5R1A106K125AB bulk capacitor: 10uF, 10V, X5R, 0805, Production
https://product.tdk.com/en/search/capacitor/ceramic/mlcc/info?part_no=CGA4J3X5R1A106K125AB

The radio schematic PDF could not be retrieved in this environment. Mapping uses S2 and S3; independently verify the actual HF-M module before release. The product page and linked controller schematic describe different regulator revisions; do not infer a guaranteed current rating from either without confirming supplied hardware.
