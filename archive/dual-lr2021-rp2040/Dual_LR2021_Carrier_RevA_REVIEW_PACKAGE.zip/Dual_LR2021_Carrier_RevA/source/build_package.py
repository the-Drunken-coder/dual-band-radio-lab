#!/usr/bin/env python3
"""Build review/assembly documentation and editable schematic from the carrier model.
All geometry units are mm. Source/deliverables remain prototype engineering-review material.
"""
from __future__ import annotations
import csv, json, math, uuid, re, hashlib, textwrap, html, zipfile
from pathlib import Path
from collections import defaultdict
from xml.etree import ElementTree as ET
from shapely import wkt
from shapely.geometry import Point, Polygon, LineString, box
from shapely.ops import unary_union
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, A3, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether
import fitz
ROOT=Path(__file__).resolve().parents[1]
M=json.loads((ROOT/'source/design_model.json').read_text())
C=M['components']; P=M['pads']; T=M['tracks']; V=M['vias']; H=M['holes']
byref={c['ref']:c for c in C}; W=M['width']; HH=M['height']
NS=uuid.UUID('c942d004-4981-43ee-b93f-fecf26a28eef')
def uid(s):return str(uuid.uuid5(NS,s))
def q(s):return json.dumps(str(s))
def nsort(s):return (re.sub(r'\d','',s),int(re.search(r'\d+',s).group()))
def writecsv(path,fields,rows):
 with path.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def rot(x,y,angle):
 a=math.radians(-angle);return (x*math.cos(a)-y*math.sin(a),x*math.sin(a)+y*math.cos(a))
def pg(p,e=0):
 if p['shape']=='circle':return Point(p['x'],p['y']).buffer(p['sx']/2+e,quad_segs=24)
 ps=[]
 for x,y in [(-p['sx']/2,-p['sy']/2),(p['sx']/2,-p['sy']/2),(p['sx']/2,p['sy']/2),(-p['sx']/2,p['sy']/2)]:
  x,y=rot(x,y,p['angle']);ps.append((p['x']+x,p['y']+y))
 return Polygon(ps).buffer(e)
def body(c):
 if c['kind']=='through_hole':x1,x2,y1,y2=-1.205,1.205,-1.525,2.54*(len(c['pads'])-1)+1.525
 elif c['ref'][0] in 'RC':x1,x2,y1,y2=-1,.0+1,-.625,.625
 elif c['ref'][0]=='U':x1,x2,y1,y2=-.625,.625,-1.05,1.05
 else:return Point(c['x'],c['y']).buffer(.7)
 return Polygon([(c['x']+rot(x,y,c['angle'])[0],c['y']+rot(x,y,c['angle'])[1]) for x,y in [(x1,y1),(x2,y1),(x2,y2),(x1,y2)]])

# Exact purchase list. Generic approved alternates for standard passives are intentional.
groups=defaultdict(list)
for c in C:
 if c['kind'] in ['smd','through_hole']:groups[c['mpn']].append(c)
rows=[]
for mpn,cs in groups.items():
 c=cs[0]
 notes='Fit exact socket geometry; no connector substitution without approval.' if c['kind']=='through_hole' else 'Equivalent passive allowed only after engineering approval.' if c['ref'][0] in 'RC' else 'Exact pin-compatible MPN; no substitution without approval.'
 if c['ref'][0]=='C':notes+=' Procurement must confirm active lifecycle/stock; listed MPN is not reserved stock.'
 if c['value']=='10uF':notes+=' TDK CGA4J3X5R1A106K125AB selected; current manufacturer status was Production. Confirm procurement and DC-bias capacitance; no silent substitution.'
 rows.append(dict(Designators=','.join(sorted([x['ref'] for x in cs],key=nsort)),Quantity=len(cs),Value=c['value'],Manufacturer=c['manufacturer'],MPN=mpn,Footprint=c['footprint'],Assembly='THT/manual' if c['kind']=='through_hole' else 'SMT',Side='Top',DNP='No',Notes=notes))
writecsv(ROOT/'assembly/BOM_carrier.csv',list(rows[0]),rows)
placements=[]
for c in C:
 if c['kind'] not in ['smd','through_hole']:continue
 # Neutral placement convention: body centroid; +X right, +Y up from lower-left.
 bc=body(c).centroid
 placements.append(dict(Designator=c['ref'],Mid_X_mm=f'{bc.x:.4f}',Mid_Y_mm=f'{HH-bc.y:.4f}',Layer='Top',Rotation_CCW_deg=c['angle'],MPN=c['mpn'],Footprint=c['footprint'],Assembly='THT/manual' if c['kind']=='through_hole' else 'SMT',Pin1_X_mm=f'{c["pads"][0]["x"]:.4f}',Pin1_Y_mm=f'{HH-c["pads"][0]["y"]:.4f}'))
writecsv(ROOT/'assembly/placements_all.csv',list(placements[0]),placements)
writecsv(ROOT/'assembly/placements_SMT_only.csv',list(placements[0]),[r for r in placements if r['Assembly']=='SMT'])
writecsv(ROOT/'assembly/placements_THT_only.csv',list(placements[0]),[r for r in placements if r['Assembly']=='THT/manual'])
module_rows=[dict(Item='Radio A and B',Quantity=2,Manufacturer='Waveshare',Model='Core2021-HF-M',SKU='34523',Header_requirement='Factory pre-soldered male headers, pins downward',Notes='HF dual-band LR2021 module; NOT bare-chip/module alternative and NOT LF. Included antennas/cables depend on ordered kit; confirm both required bands.'),dict(Item='USB-C host',Quantity=1,Manufacturer='Waveshare',Model='RP2040-Plus-M (4MB)',SKU='20808',Header_requirement='Factory pre-soldered male headers, standard 40-pin Pico layout',Notes='NOT Feather, Pico 2, RP2040-Zero or a different Plus revision without verification. USB data cable is separate. Leave battery unconnected.')]
writecsv(ROOT/'assembly/modules_optional_turnkey.csv',list(module_rows[0]),module_rows)
pinroles={
'J1':['GP0','GP1','GND','GP2','GP3','GP4','GP5','GND','GP6','GP7','GP8','GP9','GND','GP10','GP11','GP12','GP13','GND','GP14','GP15'],
'J2':['VBUS','VSYS','GND','3V3_EN','3V3_OUT','ADC_VREF','GP28','AGND','GP27','GP26','RUN','GP22','GND','GP21','GP20','GP19','GP18','GND','GP17','GP16'],
'J3':['RF_2.4GHz','GND','DIO11_IRQ','DIO8','DIO7','NC','GND','3V3'],
'J4':['RF_subGHz','GND','CS','CLK','MOSI','MISO','RESET','BUSY'],
'J5':['RF_2.4GHz','GND','DIO11_IRQ','DIO8','DIO7','NC','GND','3V3'],
'J6':['RF_subGHz','GND','CS','CLK','MOSI','MISO','RESET','BUSY']}
prows=[]
for c in C:
 for p in c['pads']:
  num=int(p['num']);phys=num if c['ref']=='J1' else 41-num if c['ref']=='J2' else ''
  prows.append(dict(Reference=c['ref'],Socket_or_component_pin=num,MCU_physical_pin=phys,Module_signal=pinroles[c['ref']][num-1] if c['ref'] in pinroles else '',Net=p['net'] if not p['net'].startswith('NC_') else 'UNCONNECTED',X_mm=p['x'],Y_from_top_mm=p['y']))
writecsv(ROOT/'docs/full_pin_mapping.csv',list(prows[0]),prows)

# Schematic: modern KiCad format with embedded symbols, all pins explicitly accounted for.
# Labels share net names. No-connect crosses are real no_connect objects, not prose.
LIBS={}
def symkind(c):
 if c['ref'][0]=='J':return 'Socket_'+str(len(c['pads']))
 if c['ref'][0]=='U':return 'TPS22919'
 if c['ref'][0]=='R':return 'R'
 if c['ref'][0]=='C':return 'C'
 return 'Testpoint'
def sympins(kind):
 if kind.startswith('Socket_'):
  n=int(kind.split('_')[1]);return [(str(i+1),-5.08,(n-1)/2*2.54-i*2.54,0,'passive',str(i+1)) for i in range(n)]
 if kind in ['R','C']:return [('1',-5.08,0,0,'passive','1'),('2',5.08,0,180,'passive','2')]
 if kind=='Testpoint':return [('1',-2.54,0,0,'passive','1')]
 return [('1',-7.62,2.54,0,'power_in','IN'),('2',-7.62,0,0,'power_in','GND'),('3',-7.62,-2.54,0,'input','ON'),('4',7.62,-2.54,180,'no_connect','NC'),('5',7.62,0,180,'passive','QOD'),('6',7.62,2.54,180,'power_out','OUT')]
def effects(size=1.27,hide=False,justify=''):
 return f'(effects (font (size {size} {size}))'+(f' (justify {justify})' if justify else '')+(' hide' if hide else '')+')'
def prop(name,value,x,y,size=1.27,hide=False):return f'(property {q(name)} {q(value)} (at {x} {y} 0) {effects(size,hide)})'
for c in C:
 k=symkind(c)
 if k in LIBS:continue
 parts=[f'(symbol "Carrier:{k}" (pin_names (offset 0.508)) (in_bom yes) (on_board yes)',prop('Reference',c['ref'][0],0,4),prop('Value',k,0,-4),prop('Footprint','',0,0,hide=True),prop('Datasheet','',0,0,hide=True)]
 geom=[]
 if k.startswith('Socket_'):
  h=int(k.split('_')[1])*1.27;geom.append(f'(rectangle (start -2.54 {h}) (end 2.54 {-h}) (stroke (width 0.254) (type default)) (fill (type background)))')
 elif k=='R':geom.append('(rectangle (start -2.54 1.016) (end 2.54 -1.016) (stroke (width 0.254) (type default)) (fill (type none)))')
 elif k=='C':
  for x in [-.762,.762]:geom.append(f'(polyline (pts (xy {x} -1.778) (xy {x} 1.778)) (stroke (width 0.254) (type default)) (fill (type none)))')
 elif k=='TPS22919':geom.append('(rectangle (start -5.08 5.08) (end 5.08 -5.08) (stroke (width 0.254) (type default)) (fill (type background)))')
 else:geom.append('(circle (center 0 0) (radius 0.762) (stroke (width 0.254) (type default)) (fill (type none)))')
 parts.append(f'(symbol "{k}_0_1" '+''.join(geom)+')')
 pins=[]
 for num,x,y,a,ty,nam in sympins(k):
  leng=2.54 if k!='C' else 4.318
  pins.append(f'(pin {ty} line (at {x} {y} {a}) (length {leng}) (name {q(nam)} {effects(1.016)}) (number {q(num)} {effects(1.016)}))')
 parts.append(f'(symbol "{k}_1_1" '+''.join(pins)+'))');LIBS[k]='\n'.join(parts)
# generous A2 landscape layout; separate sections avoid overlapping labels.
locs={'J1':(55,65),'J2':(150,65),'J3':(280,45),'J4':(280,90),'J5':(400,45),'J6':(400,90),'U1':(60,160),'U2':(180,160)}
for row,refs in enumerate([['R1','R2','R3','R4','R5','R6'],['R7','R8','R9','R10','R11','R12'],['C1','C2','C3','C4','C5','C6']]):
 for col,ref in enumerate(refs):locs[ref]=(50+88*col,220+38*row)
for i in range(1,9):locs[f'TP{i}']=(45+69*(i-1),346)
sch=[f'(kicad_sch (version 20230121) (generator dual_lr2021_generator) (uuid {uid("root")}) (paper "A2")', '(title_block (title "Dual LR2021 socketed carrier") (date "2026-10-13") (rev "A") (company "Lane Araujo") (comment 1 "ENGINEERING REVIEW REQUIRED - NOT RELEASED"))','(lib_symbols '+''.join(LIBS.values())+')']
for c in C:
 k=symkind(c);cx,cy=locs[c['ref']];sp=sympins(k)
 inst=[f'(symbol (lib_id "Carrier:{k}") (at {cx} {cy} 0) (unit 1) (in_bom {"no" if c["kind"]=="testpoint" else "yes"}) (on_board yes) (dnp no) (uuid {c["uuid"]})']
 top=int(k.split('_')[1])*1.27+4 if k.startswith('Socket_') else 8 if k=='TPS22919' else 6
 inst += [prop('Reference',c['ref'],cx,cy-top),prop('Value',c['value'],cx,cy-top+2.3,1.016),prop('Footprint','Carrier:'+c['footprint'],cx,cy,hide=True),prop('Datasheet','',cx,cy,hide=True),prop('MPN',c['mpn'],cx,cy,hide=True)]
 for num,x,y,a,ty,nam in sp:
  inst.append(f'(pin {q(num)} (uuid {uid(c["ref"]+"/pin/"+num)}))')
  px,py=cx+x,cy-y;net=next(p['net'] for p in c['pads'] if p['num']==num)
  if net.startswith('NC_'):sch.append(f'(no_connect (at {px} {py}) (uuid {uid(c["ref"]+"/nc/"+num)}))')
  else:
   lx=px-5.08 if x<0 else px+5.08
   sch.append(f'(wire (pts (xy {px} {py}) (xy {lx} {py})) (stroke (width 0) (type default)) (uuid {uid(c["ref"]+"/wire/"+num)}))')
   # Label extends away from the symbol; left pins right-justify their text.
   just='right bottom' if x<0 else 'left bottom'
   sch.append(f'(label {q(net)} (at {lx} {py} 0) {effects(.95,False,just)} (uuid {uid(c["ref"]+"/label/"+num)}))')
 inst.append(f'(instances (project "Dual_LR2021_Carrier" (path "/{uid("root")}" (reference {q(c["ref"])}) (unit 1)))))');sch.append('\n'.join(inst))
notes=[(20,15,'HOST SOCKETS: TOP VIEW, USB-C AT UPPER EDGE. J2.1 = MCU40; J2.20 = MCU21.'),(243,15,'RADIO SOCKET PAIRS: ANTENNA CONTACTS NOT ROUTED. DIO7/DIO8 UNUSED.'),(20,123,'POWER: +3V3 comes ONLY from the approved MCU 3V3 output; do not apply USB 5V here.'),(20,132,'U1/U2 are load switches, NOT voltage regulators. ON pull-downs keep both radios OFF at boot.'),(20,187,'Before disabling power, set all host-to-radio pins to high impedance with no pull-up. Prevent GPIO back-powering.'),(20,197,'All connected labels of the same name are the same electrical net. Crosses denote deliberate no-connects.'),(20,373,'NATIVE ERC/DRC NOT RUN. Check footprint mirroring, actual module revisions, USB current policy, and first-article behavior.'),(20,384,'REFILL/RE-EXPORT ONLY AFTER NATIVE REVIEW. Gerber package contains an exact snapshot of the generated prototype layout.')]
for i,(x,y,txt) in enumerate(notes):sch.append(f'(text {q(txt)} (at {x} {y} 0) {effects(1.6,False,"left top")} (uuid {uid("note/"+str(i))}))')
sch.append(')');(ROOT/'source/Dual_LR2021_Carrier.kicad_sch').write_text('\n'.join(sch))
# A library file permits symbol reuse as well as fully embedded schematic operation.
(ROOT/'source/Carrier.kicad_sym').write_text('(kicad_symbol_lib (version 20220914) (generator dual_lr2021_generator)\n'+ '\n'.join(v.replace('"Carrier:'+k+'"','"'+k+'"',1) for k,v in LIBS.items())+'\n)')
(ROOT/'source/sym-lib-table').write_text('(sym_lib_table (lib (name "Carrier") (type "KiCad") (uri "${KIPRJMOD}/Carrier.kicad_sym") (options "") (descr "Custom prototype carrier symbols")))\n')
# Neutral, machine-readable netlist. No-connect pads are deliberately absent from nets.
ex=ET.Element('export',version='E');des=ET.SubElement(ex,'design');ET.SubElement(des,'source').text='Dual_LR2021_Carrier.kicad_sch';ET.SubElement(des,'date').text='2026-10-13';ET.SubElement(des,'tool').text='dual_lr2021_generator (not native KiCad-validated)'
co=ET.SubElement(ex,'components')
for c in C:
 ce=ET.SubElement(co,'comp',ref=c['ref']);ET.SubElement(ce,'value').text=c['value'];ET.SubElement(ce,'footprint').text='Carrier:'+c['footprint'];ET.SubElement(ce,'tstamps').text=c['uuid']
netel=ET.SubElement(ex,'nets')
for i,n in enumerate(sorted({p['net'] for p in P if not p['net'].startswith('NC_')}),1):
 nn=ET.SubElement(netel,'net',code=str(i),name=n)
 for p in P:
  if p['net']==n:ET.SubElement(nn,'node',ref=p['ref'],pin=p['num'])
ET.indent(ex);ET.ElementTree(ex).write(ROOT/'source/Dual_LR2021_Carrier.net',encoding='utf-8',xml_declaration=True)

# Source references and deliberate engineering assumptions, not claims of vendor qualification.
sources=[
('S1','Waveshare Core2021-XF documentation / exact HF-M SKU','https://docs.waveshare.com/Core2021-XF'),
('S2','Radio underside labels (mirror horizontally for top view)','https://docs.waveshare.com/assets/images/Core2021-HF-Product-introduce-02-8055d4bcd0081527f6cc924f00d8c3b0.webp'),
('S3','Radio dimensional image (shared family drawing; independently verify HF-M)','https://docs.waveshare.com/assets/images/Core2021-HF-Product-introduce-03-9592b4d1100c62739ad133b74507ebfc.webp'),
('S4','Waveshare RP2040-Plus / -M documentation','https://docs.waveshare.com/RP2040-Plus'),
('S5','RP2040-Plus dimensional drawing','https://docs.waveshare.com/assets/images/RP2040-Plus-details-size-6c1430864c01e95cbf22c9d4c128e82c.webp'),
('S6','RP2040-Plus linked schematic (TPS63000 version)','https://files.waveshare.com/wiki/RP2040-Plus/RP2040_Plus.pdf'),
('S7','TI TPS22919 datasheet and DCK0006A land pattern','https://www.ti.com/lit/ds/symlink/tps22919.pdf'),
('S8','Samtec SSW through-hole recommended footprint','https://suddendocs.samtec.com/prints/ssw-s.pdf'),
('S9','Samtec SSW series mechanical print','https://suddendocs.samtec.com/prints/ssw-1xx-xx-xxx-x-xx-xxx-xx-mkt.pdf'),
('S10','JLCPCB PCBA scope / through-hole assembly FAQ (not an acceptance or quote)','https://jlcpcb.com/help/article/pcb-assembly-faqs'),
('S11','KiCad board S-expression format','https://dev-docs.kicad.org/en/file-formats/sexpr-pcb/'),
('S12','KiCad schematic S-expression format','https://dev-docs.kicad.org/en/file-formats/sexpr-schematic/'),
('S13','Semtech LR2021 datasheet copy, typical TX current reference','https://www.mouser.com/pdfDocs/61979758LR2021_V1_1_datasheet.pdf'),
('S14','TDK CGA4J3X5R1A106K125AB bulk capacitor: 10uF, 10V, X5R, 0805, Production','https://product.tdk.com/en/search/capacitor/ceramic/mlcc/info?part_no=CGA4J3X5R1A106K125AB')]
(ROOT/'docs/SOURCES.md').write_text('# Source register\n\nAccessed 2026-10-13. URLs are references, not bundled manufacturer intellectual property.\n\n'+'\n\n'.join(f'## {i} - {title}\n{url}' for i,title,url in sources)+'\n\nThe radio schematic PDF could not be retrieved in this environment. Mapping uses S2 and S3; independently verify the actual HF-M module before release. The product page and linked controller schematic describe different regulator revisions; do not infer a guaranteed current rating from either without confirming supplied hardware.\n')

# PDF drawing utility. Programmatic CAD geometry, not an artistic rendering.
INK=colors.HexColor('#142936');ACC=colors.HexColor('#265563');MUT=colors.HexColor('#536572');LIGHT=colors.HexColor('#e9eff2')
def drawshape(cv,g,x0,y0,scale,fill,stroke=None,lw=.15):
 if g.is_empty:return
 geos=[g] if g.geom_type=='Polygon' else list(g.geoms)
 cv.setFillColor(fill);cv.setStrokeColor(stroke or fill);cv.setLineWidth(lw)
 for po in geos:
  if po.geom_type!='Polygon':continue
  path=cv.beginPath()
  for ring in [po.exterior]+list(po.interiors):
   for i,(x,y) in enumerate(ring.coords):
    xx=x0+x*scale;yy=y0+(HH-y)*scale
    if i==0:path.moveTo(xx,yy)
    else:path.lineTo(xx,yy)
   path.close()
  cv.drawPath(path,fill=1,stroke=int(stroke is not None),fillMode=0)

def headerpdf(cv,title,subtitle='',size=A4):
 pw,ph=size;cv.setFillColor(INK);cv.rect(0,ph-77,pw,77,fill=1,stroke=0);cv.setFillColor(colors.white);cv.setFont('Helvetica-Bold',19);cv.drawString(30,ph-34,title);cv.setFont('Helvetica',9);cv.drawString(30,ph-55,subtitle)
 cv.setFillColor(MUT);cv.setFont('Helvetica',8);cv.drawString(30,18,'DUAL LR2021 CARRIER / REV A / 13 OCT 2026');cv.drawRightString(pw-30,18,'ENGINEERING REVIEW REQUIRED - NOT RELEASED')

def boarddraw(cv,x0,y0,scale,mode='assembly',modules=True):
 # Top view always; bottom copper is deliberately not mirrored to ease net comparison.
 bg=colors.HexColor('#fafbfc') if mode=='assembly' else colors.HexColor('#143f37')
 cv.setFillColor(bg);cv.setStrokeColor(INK);cv.setLineWidth(.6);cv.rect(x0,y0,W*scale,HH*scale,fill=1,stroke=1)
 if mode!='assembly':
  layer=mode
  if layer in ['In1.Cu','B.Cu']:
   plane=wkt.loads(json.loads((ROOT/'source/planes.json').read_text())[layer]);drawshape(cv,plane,x0,y0,scale,colors.HexColor('#a79149'))
  else:
   for t in T:
    if t['layer']==layer:drawshape(cv,LineString(t['points']).buffer(t['width']/2),x0,y0,scale,colors.HexColor('#d8b76b'))
 for p in P:
  if mode not in ['assembly','F.Cu'] and p['kind']!='thru_hole':continue
  drawshape(cv,pg(p),x0,y0,scale,colors.HexColor('#a89561') if mode=='assembly' else colors.HexColor('#e2c475'))
 for v in V:
  cv.setFillColor(colors.HexColor('#bbb7a3'));cv.circle(x0+v['x']*scale,y0+(HH-v['y'])*scale,v['diameter']/2*scale,fill=1,stroke=0)
  cv.setFillColor(colors.white if mode=='assembly' else colors.HexColor('#08231e'));cv.circle(x0+v['x']*scale,y0+(HH-v['y'])*scale,v['drill']/2*scale,fill=1,stroke=0)
 if mode=='F.Cu':drawshape(cv,wkt.loads((ROOT/'source/silkscreen.wkt').read_text()),x0,y0,scale,colors.HexColor('#f0f2dc'))
 if mode=='assembly':
  for c in C:
   if c['kind'] not in ['smd','through_hole']:continue
   # Hollow body outline, not copper.
   b=body(c);path=cv.beginPath()
   for i,(x,y) in enumerate(b.exterior.coords):
    if i==0:path.moveTo(x0+x*scale,y0+(HH-y)*scale)
    else:path.lineTo(x0+x*scale,y0+(HH-y)*scale)
   cv.setStrokeColor(INK);cv.setLineWidth(.5);cv.drawPath(path,fill=0,stroke=1)
   p=c['pads'][0];cv.setFillColor(INK);cv.circle(x0+p['x']*scale,y0+(HH-p['y'])*scale,.23*scale,fill=1,stroke=0)
   if c['kind']=='smd':
    cv.setFont('Helvetica',max(6,scale*1.2));cv.drawCentredString(x0+c['x']*scale,y0+(HH-c['y']+1.95)*scale,c['ref'])
  # Radio / host outlines are envelopes derived from vendor drawing, not full 3D models.
  if modules:
   cv.setDash(3,2);cv.setStrokeColor(ACC);cv.setLineWidth(.7)
   for x,y,w,h in [(39.5,.23,21,51),(7.51,30.58,22,19),(70.49,32.42,22,19)]:cv.rect(x0+x*scale,y0+(HH-y-h)*scale,w*scale,h*scale,fill=0,stroke=1)
   cv.setDash();cv.setFillColor(ACC);cv.setFont('Helvetica-Bold',max(8,scale*1.8))
   for txt,x,y in [('MCU',50,56),('RADIO A',18.5,40.5),('RADIO B',81.5,41.5),('USB-C',50,-2.7)]:cv.drawCentredString(x0+x*scale,y0+(HH-y)*scale,txt)
   for x,y,sgn in [(17,44,-1),(83,45,1)]:
    cv.setLineWidth(1);cv.line(x0+x*scale,y0+(HH-y)*scale,x0+(x+sgn*6)*scale,y0+(HH-y)*scale)
    cv.line(x0+(x+sgn*6)*scale,y0+(HH-y)*scale,x0+(x+sgn*4.5)*scale,y0+(HH-y+1)*scale)
    cv.line(x0+(x+sgn*6)*scale,y0+(HH-y)*scale,x0+(x+sgn*4.5)*scale,y0+(HH-y-1)*scale)
   cv.setFont('Helvetica',max(7,scale*1.3));cv.drawCentredString(x0+18.5*scale,y0+(HH-46.8)*scale,'ANTENNAS LEFT');cv.drawCentredString(x0+81.5*scale,y0+(HH-47.8)*scale,'ANTENNAS RIGHT')
  for r,x,y in [('J1',37,25),('J2',63,25),('J3',18,51.6),('J4',18,31.1),('J5',82,31),('J6',82,53)]:
   cv.setFont('Helvetica-Bold',max(7,scale*1.4));cv.setFillColor(INK);cv.drawCentredString(x0+x*scale,y0+(HH-y)*scale,r)
 for p in P:
  if p['drill']:
   cv.setFillColor(colors.white);cv.circle(x0+p['x']*scale,y0+(HH-p['y'])*scale,p['drill']/2*scale,fill=1,stroke=0)
 for h in H:
  cv.setFillColor(colors.white);cv.setStrokeColor(INK);cv.circle(x0+h['x']*scale,y0+(HH-h['y'])*scale,h['drill']/2*scale,fill=1,stroke=1)
 # Dimension lines outside board.
 cv.setStrokeColor(MUT);cv.setFillColor(MUT);cv.setLineWidth(.5)
 cv.line(x0,y0-14,x0+W*scale,y0-14)
 for x in [x0,x0+W*scale]:cv.line(x,y0-18,x,y0-10)
 cv.setFont('Helvetica',9);cv.drawCentredString(x0+W*scale/2,y0-27,'100.00 mm')
 cv.saveState();cv.translate(x0-18,y0+HH*scale/2);cv.rotate(90);cv.drawCentredString(0,0,'70.00 mm');cv.restoreState()

# Assembly drawing, readable circuit drawing, and board layers are separate useful files.
size=landscape(A4);pw,ph=size
cv=canvas.Canvas(str(ROOT/'assembly/assembly_drawing.pdf'),pagesize=size)
headerpdf(cv,'Assembly drawing - top view','All 26 fitted components on TOP. Dashed outlines are plug-in modules, not soldered components.',size)
boarddraw(cv,50,115,4.4,'assembly',True)
cv.setFillColor(INK);cv.setFont('Helvetica-Bold',10);cv.drawString(540,470,'Orientation / installation')
lines=['MCU: USB-C faces upper board edge.','Radio A: antenna end faces LEFT.','Radio B: antenna end faces RIGHT.','All modules: components/shield facing UP.','Square pad = socket local pin 1.','','J1.1 = MCU pin 1 (GP0).','J2.1 = MCU pin 40 (VBUS, not routed).','J2.20 = MCU pin 21 (GP16).','','Sockets: 2 x 20-way + 4 x 8-way.','Pitch: 2.54 mm. Housing height: 8.51 mm.','PTH holes: 1.04 mm finished diameter.','','THT sockets require factory soldering.','Do not omit them from the assembly quote.','','Disconnect all power before insertion.','Align both rows; do not shift one position.','No module or RF functional test performed.']
cv.setFont('Helvetica',9)
for i,s in enumerate(lines):cv.drawString(540,450-15*i,s)
cv.setFont('Helvetica',9);cv.drawString(45,55,'Board: 100 x 70 x 1.6 mm. Four M3 clearance holes, diameter 3.2 mm. Do not let metal hardware contact nearby copper.')
cv.showPage();headerpdf(cv,'Assembly detail - soldered carrier','Module envelopes removed. SMT reference labels and pin-1 markers are shown; all parts fit on TOP.',size);boarddraw(cv,60,85,5.3,'assembly',False)
cv.setFillColor(INK);cv.setFont('Helvetica',9)
for i,s in enumerate(['U1/U2: pin 1 IN at upper left in this view.','TI SC70-6: 1 IN / 2 GND / 3 ON /','4 NC / 5 QOD / 6 OUT.','QOD is tied to its own OUT net.','','Only U1/U2 have meaningful polarity.','Resistors and MLCC capacitors are nonpolar.','','Generic centroids are provided.','Assembler must check machine rotation','against pin 1 and the component package.','','TP1..TP8 are exposed PCB pads;','there are no separate testpoint parts.','','No components are fitted on the bottom.']):cv.drawString(625,450-i*16,s)
cv.save()
# Actual copper previews at common scale.
cv=canvas.Canvas(str(ROOT/'docs/board_layers.pdf'),pagesize=size)
for layer in M['layers']:
 headerpdf(cv,'Copper layout - '+layer,'All pages use top-view coordinates. Layer 2 and layer 4 are ground planes.',size);boarddraw(cv,165,82,5.3,layer,False);cv.showPage()
cv.save()
# A compact schematic PDF with one-page sections. Draw every terminal/net from same model.
cv=canvas.Canvas(str(ROOT/'docs/schematic.pdf'),pagesize=landscape(A3));pw3,ph3=landscape(A3)
def schematic_part(cv,c,x,y,sc=1.4):
 k=symkind(c);pins=sympins(k);h=int(k.split('_')[1])*1.27 if k.startswith('Socket_') else 5.08 if k=='TPS22919' else 2.4
 bw=5.08 if k=='TPS22919' else 2.54
 # coordinates mm scaled to points for schematic only; x,y supplied in points
 cv.setStrokeColor(INK);cv.setFillColor(colors.white);cv.setLineWidth(.8);cv.rect(x-bw*sc,y-h*sc,2*bw*sc,2*h*sc,fill=1,stroke=1)
 cv.setFillColor(INK);cv.setFont('Helvetica-Bold',9);cv.drawCentredString(x,y+h*sc+18,c['ref']);cv.setFont('Helvetica',8);cv.drawCentredString(x,y+h*sc+7,c['value'])
 for num,px,py,a,ty,nm in pins:
  p=next(p for p in c['pads'] if p['num']==num);sx=x+px*sc;sy=y+py*sc;end=sx+(-17 if px<0 else 17)
  cv.line(x+(-bw if px<0 else bw)*sc,sy,end,sy);cv.setFont('Helvetica',6.2)
  cv.drawString(x+(-bw+0.5)*sc if px<0 else x+.4,sy+2,num)
  cv.setFont('Helvetica',7.6)
  net=p['net']
  if net.startswith('NC_'):
   cv.line(end-2,sy-2,end+2,sy+2);cv.line(end-2,sy+2,end+2,sy-2)
   # annotate NC signal, particularly RF contacts.
   val=pinroles[c['ref']][int(num)-1]+' / NC' if c['ref'] in pinroles else 'NC'
  else:val=net
  if px<0:cv.drawRightString(end-4,sy+2,val)
  else:cv.drawString(end+4,sy+2,val)

headerpdf(cv,'Electrical schematic - host and radios','Net labels are electrical connections. NC means intentionally unconnected on carrier. Complete editable schematic included.',landscape(A3))
for ref,x,y in [('J1',190,425),('J2',460,425),('J3',760,525),('J4',760,305),('J5',1035,525),('J6',1035,305)]:schematic_part(cv,byref[ref],x,y,7.1 if ref in ['J1','J2'] else 6.0)
cv.setFillColor(INK);cv.setFont('Helvetica',10)
for i,s in enumerate(['J1 local numbering runs MCU 1 -> 20; J2 local numbering runs MCU 40 -> 21. Do not use socket numbers as GPIO numbers.','Radio A = SPI1 on GP8/10/11, CS GP9. Radio B = SPI0 on GP16/18/19, CS GP17.','33-ohm damping resistors split SCK/MOSI/MISO into host-side and radio-side net names. See next sheet.','Module power is 3.3 V only. RF header contacts have isolated copper pads; antennas remain on the radio modules.']):cv.drawString(45,112-16*i,s)
cv.showPage();headerpdf(cv,'Electrical schematic - power and support','U1/U2 are load switches, NOT regulators. Source +3V3 is supplied by the approved MCU module.',landscape(A3))
for ref,x,y in [('U1',230,640),('U2',700,640)]:schematic_part(cv,byref[ref],x,y,5)
for row,refs in enumerate([['R1','R2','C1','C2'],['R3','R4','R5','R6'],['C3','C4','C5','C6'],['R7','R8','R9'],['R10','R11','R12']]):
 for col,ref in enumerate(refs):schematic_part(cv,byref[ref],190+280*col,510-86*row,3)
cv.setFont('Helvetica',10);cv.drawString(45,55,'All EN pull-downs are 100k. CS/RESET pull-ups go to each switched radio rail; host pins must not back-power an OFF radio.')
cv.showPage();headerpdf(cv,'Electrical schematic - probe points','Probe pads are copper features, not separately purchased components.',landscape(A3))
for i in range(1,9):schematic_part(cv,byref[f'TP{i}'],220+270*((i-1)%4),620-180*((i-1)//4),5)
cv.setFont('Helvetica',11)
for i,s in enumerate(['TP1 = source 3V3. TP2 = ground. TP3 = switched Radio A power. TP4 = switched Radio B power.','TP5/TP6 = Radio A BUSY / IRQ. TP7/TP8 = Radio B BUSY / IRQ.','No USB data traces or RF transmission lines are present on the carrier.','For unpowered fixture testing, remove all three modules. Do not inject 5 V onto TP1.','Hardware revision, electrical review, native ERC/DRC, external CAM/DFM and first-article tests remain outstanding.']):cv.drawString(55,235-25*i,s)
cv.save()

# Readable engineering/order packet, with explicit release gates and limited claims.
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyX',fontName='Helvetica',fontSize=10,leading=14,spaceAfter=8,textColor=INK))
styles.add(ParagraphStyle(name='SmallX',fontName='Helvetica',fontSize=8,leading=11,spaceAfter=5,textColor=INK))
styles.add(ParagraphStyle(name='HeadX',fontName='Helvetica-Bold',fontSize=16,leading=20,spaceAfter=12,textColor=INK))
styles.add(ParagraphStyle(name='SubX',fontName='Helvetica-Bold',fontSize=11,leading=15,spaceBefore=8,spaceAfter=6,textColor=ACC))
def para(s,style='BodyX'):return Paragraph(s,styles[style])
def tab(data,widths=None):
 d=[[para(html.escape(str(v)),'SmallX') for v in row] for row in data];t=Table(d,colWidths=widths,repeatRows=1,hAlign='LEFT');t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),LIGHT),('VALIGN',(0,0),(-1,-1),'TOP'),('BOX',(0,0),(-1,-1),.5,colors.HexColor('#bdcbd2')),('INNERGRID',(0,0),(-1,-1),.3,colors.HexColor('#d7e0e5')),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]));return t
story=[]
def title(s):story.append(para(s,'HeadX'))
def sub(s):story.append(para(s,'SubX'))
def p(s):story.append(para(s))
def page():story.append(PageBreak())
title('Dual LR2021 carrier | Rev A')
p('<b>Prototype design and manufacturing handoff package</b><br/>Prepared for Lane Araujo / 13 October 2026')
p('<b>RELEASE HOLD: engineering review required.</b> These are actual generated PCB, schematic, Gerber, drill, BOM and placement files, but they are not a tested or independently approved production design. Send the package for review and quotation; do not authorize a blind production run.')
sub('What this board does')
p('A 100 x 70 mm carrier replaces jumper wiring with sockets for two Waveshare Core2021-HF-M LR2021 modules and one Waveshare RP2040-Plus-M USB-C controller. Radio A and B have separate hardware SPI buses, independent enable-controlled 3.3 V power switches, local bypass capacitors, reset/chip-select pulls and probe pads. All factory-fitted parts are on top.')
p('USB-C and its USB circuitry remain on the controller. Antenna connectors and RF circuitry remain on each radio. The carrier does not implement a mesh protocol, USB-to-radio application, RF filtering, or full-duplex interference cancellation.')
sub('No soldering for the owner')
p('Order <b>assembled PCBA with SMT and through-hole assembly</b>, not bare PCB fabrication. The six female socket strips must be factory soldered. In the base option, the owner only inserts three pre-headered modules. For a completely populated delivery, have the assembler procure and insert the modules in the optional system BOM. Firmware installation and radio validation are separate work.')
sub('Package navigation')
story.append(tab([['Folder','Contents'],['source/','Editable KiCad board, schematic, libraries, netlist, model and reproducible Python sources.'],['manufacturing/','Gerber/drill files, fabrication requirements, file manifest and order hold notice.'],['assembly/','Carrier BOM, SMT/THT placement lists, module procurement list, assembly drawing and RFQ.'],['verification/','Custom checks and readback reports; list of unexecuted checks.'],['docs/','Schematic PDF, copper views, full pin map, source register and this packet.'],['firmware/','Pin map and power-control requirements only; not a completed radio application.']],[100,410]))
page();title('01 | Locked module choices')
story.append(tab([['Part','Quantity','Exact model'],['Radio module','2','Waveshare Core2021-HF-M, SKU 34523; factory male headers.'],['Controller','1','Waveshare RP2040-Plus-M, 4MB, SKU 20808; factory male headers.'],['Carrier socket','2','Samtec SSW-120-01-G-S, 20 contacts.'],['Carrier socket','4','Samtec SSW-108-01-G-S, 8 contacts.']],[120,60,330]))
p('Sources: S1-S6, S8-S9. Do not substitute a Feather, RP2040-Zero, bare Pico, LF radio or another LR2021 board on the assumption that the pinouts match.')
sub('Mechanical orientation')
p('View the carrier from its component side. Controller USB-C points toward the upper edge. Radio A points its antenna end left; Radio B points its antenna end right. All module component/shield sides face up. Both connector rows must align without force or one-position offset. The sockets are not keyed, so orientation is a mandatory inspection.')
p('Radio pin order was derived from the vendor underside photograph, then mirrored for top-side mating. The family dimension image shows 2.54 mm pitch, 15.24 mm radio-row spacing and 22 x 19 mm PCB size. The MCU has 17.78 mm row spacing and a 21 x 51 mm PCB. Socket housing dimensions follow the Samtec print; actual male-header insertion depth and module revision must still be checked [S2, S3, S5, S8, S9].')
sub('Why four copper layers')
p('Design choice: F.Cu carries signals/components, In1.Cu is ground, In2.Cu carries additional signals and B.Cu is ground. This preserves ground references around the two independent SPI buses without squeezing a first prototype into an unnecessarily small board. It does not make co-located transmitters immune to receiver desensitization.')
sub('Procurement and substitutions')
p('The 10 uF bulk capacitor is TDK CGA4J3X5R1A106K125AB: 10 V, X5R, 0805, listed by TDK as Production at review [S14]. The BOM lists exact MPNs, but availability must still be checked at quote time. Any substitute needs engineering approval for size, voltage, tolerance and DC-bias behavior; allow up to 1.5 mm capacitor body height. No inventory is reserved and no assembler-specific component IDs are invented.')
page();title('02 | Signal and power allocation')
story.append(tab([['Function','Radio A / SPI1','Radio B / SPI0'],['MISO','GP8, physical 11','GP16, physical 21'],['CS','GP9, physical 12','GP17, physical 22'],['SCK','GP10, physical 14','GP18, physical 24'],['MOSI','GP11, physical 15','GP19, physical 25'],['BUSY','GP12, physical 16','GP20, physical 26'],['DIO11 / IRQ','GP13, physical 17','GP21, physical 27'],['RESET','GP14, physical 19','GP22, physical 29'],['Power ON','GP6, physical 9','GP26, physical 31']],[115,197,198]))
p('These GPIO choices are design allocations. MCU physical pin numbers are not the local J2 socket numbers: J2 local pin 1 is physical 40 and J2 local pin 20 is physical 21. See full_pin_mapping.csv for every terminal.')
sub('Power path')
p('Controller 3V3_OUT (physical 36 / J2.5) feeds +3V3. U1 switches this to A_3V3 and U2 to B_3V3. TPS22919 is a load switch, not a regulator; its 1.5 A device rating is not a current entitlement from USB or the controller regulator [S7]. Each ON input has 100k to ground, so both radios default off. QOD is tied to OUT for discharge when off. Each radio has 100 nF and 10 uF local bypass, with 1 uF at each switch input.')
p('Do not connect a battery in this revision. Do not power the carrier from the controller VBUS pin: it is deliberately not routed. Do not connect external power and USB simultaneously. All carrier logic and radio power are nominal 3.3 V.')
sub('Power budget: preliminary, not a guaranteed maximum')
p('LR2021 typical TX current at +22 dBm on 915 MHz is approximately 105 mA [S13]. Two such radio chips give <b>2 x 105 = 210 mA</b>. An assumed 100 mA controller allowance gives 310 mA before module overhead and margin; this is an engineering budget, not a measured or guaranteed worst-case result. Validate actual hardware and transmit bursts before approval.')
p('At 120 mA and 90 milliohms typical switch resistance, a switch drops about <b>0.120 x 0.090 = 10.8 mV</b> and dissipates <b>0.120^2 x 0.090 = 1.30 mW</b>. Use worst-case datasheet resistance for release calculations. Board power paths are 0.25 mm wide; verify total path drop using exported trace lengths, final copper thickness and measured load.')
page();title('03 | Fabrication and assembly requirements')
story.append(tab([['Item','Requirement'],['Board / layers','100.00 x 70.00 mm; 4 copper layers; 1.60 mm finished thickness.'],['Material','FR-4, Tg >=150 C; lead-free compatible.'],['Copper','35 um finished outer copper; inner copper >=18 um. Standard symmetric stackup, subject to reviewer and fabricator approval.'],['Finish / mask','Lead-free ENIG; green solder mask; white top silkscreen; no bottom assembly.'],['Trace / spacing','Nominal signal width 0.20 mm; power 0.25 mm; minimum different-net clearance 0.20 mm.'],['Vias','0.60 mm copper diameter / 0.30 mm finished plated hole; through vias; tented, no via-in-pad.'],['Sockets','1.85 mm pads / 1.04 mm finished plated holes / 2.54 mm pitch.'],['Mounting','Four 3.20 mm NPTH holes at (5,5), (95,5), (5,65), (95,65) mm from top-left.'],['Drill separation','PTH and NPTH are separate files. Do not merge plating classes.'],['Electrical test','Require bare-board continuity/isolation test against customer netlist/CAM.'],['Assembly','20 SMT parts plus 6 through-hole sockets; all top side; 26 fitted carrier parts total.'],['Centroid convention','mm; origin lower-left; +X right, +Y up; rotation counterclockwise. Check U1/U2 pin 1 and socket local pin 1 in drawing.']],[135,375]))
p('The delivered neutral centroid files are not asserted to match a particular machine library. The assembler must map package rotations and confirm THT/manual insertion capability. Match BOM MPNs to package drawings. Do not silently drop unavailable sockets or replace them with male headers.')
p('No controlled-impedance RF geometry is specified because no intentional RF paths are routed on the carrier. The RF socket contacts have isolated copper pads and local keepouts; do not attach carrier RF traces or repurpose them without a redesign. Verify how the actual module connects its RF header pads: an isolated carrier pad is not RF isolation, and a connected socket contact can add an RF stub. Antenna-port/jumper state and RF performance must be reviewed on the first article.')
page();title('04 | Release gates and verification')
sub('Checks performed in this package')
p('The custom geometry checker tests different-net copper clearance, copper-to-board/NPTH clearance, and terminal connectivity through copper, plated holes and vias. The generated model reported zero violations. Export readback, syntax and file-consistency results are supplied separately in verification/. These checks are useful but are not native KiCad ERC/DRC, a certified CAM checker or a physical test.')
sub('Required before authorizing fabrication')
p('<b>1. Independent electrical and mechanical review.</b> Confirm exact module revisions, radio top/bottom orientation, socket pitch and male pin engagement, GPIO alternate functions, switch pin mapping, current budget and regulator revision. The radio schematic PDF was not read here; the photo-derived pin mapping is a specific release gate.')
p('<b>2. Native CAD validation.</b> Open the project in KiCad, verify symbols and footprints, perform ERC, refill zones, run DRC, check courtyard and silkscreen warnings, and compare the native netlist to the pin mapping. Native KiCad import, ERC and DRC could not be executed in this environment. Automatically updating from the schematic may normalize the custom NC pad-net names; they must remain unrouted.')
p('<b>3. Export and DFM review.</b> Inspect all Gerber and drill layers in an independent CAM viewer. Confirm layer order, holes, mask/paste, plane connectivity and board outline. After native changes, regenerate the entire manufacturing set; never mix revisions. Ask the assembler to approve the SMT/THT process, rotations, socket sourcing, and any passive substitutions.')
p('<b>4. First article, not an immediate batch.</b> After the above gates, build the smallest practical prototype lot and test one first article before wider assembly. Sign-off means actual results, not a manufacturer merely accepting an uploaded ZIP.')
sub('What has not been established')
p('No fabrication quote or vendor acceptance; no tested USB firmware; no proof of uninterrupted dual-radio operation, RF isolation, maximum throughput, environmental robustness, antenna match, regulatory compliance or flight suitability. This is a bench prototype, not a qualified mission-critical component.')
sub('Controller regulator discrepancy')
p('The current RP2040-Plus page and its linked schematic describe different regulator implementations. This package does not equate a switch-current or marketing rating with guaranteed available 3.3 V output. Verify the actual SKU/revision and thermal performance at the agreed load before release [S4, S6].')
page();title('05 | Bring-up and firmware contract')
sub('Unpowered inspection first')
p('Remove all three plug-in modules. Inspect solder joints, U1/U2 orientation, socket alignment, lead clearance and debris. Check socket contact numbering against the assembly drawing and continuity against the netlist. Capacitors can cause transient resistance readings; do not mistake normal charging for a short. Confirm no static low-resistance path from each supply rail to ground.')
sub('Controlled carrier-only supply check')
p('A qualified reviewer may power TP1 with a current-limited 3.3 V laboratory supply and TP2 ground while the MCU and radios are absent. Start with a low current limit appropriate to an unloaded carrier. Both switched rails should remain off. A test fixture may drive each EN node high to enable one switch and check its output under a dummy load. Never inject 5 V at TP1, and never drive EN or a radio I/O above the active supply. Remove the fixture supply before inserting the MCU.')
sub('Firmware responsibilities')
p('The supplied pinmap.h is a mapping file, not a radio driver. Before enabling either switch, place all host-to-radio GPIOs in a defined high-impedance, no-pull state and keep both enables low. Use firmware and USB descriptors that respect the source current contract; enable radio loads only when permitted, and handle USB suspend. A USB-C connector alone does not establish an unlimited current budget.')
p('Enable one radio, allow its supply to stabilize (initial test delay at least 10 ms), then establish a safe inactive chip-select level and apply the reset/initialization sequence required by the actual module/driver. Start SPI at a low rate, such as 1 MHz, and validate each bus separately before increasing it. Obey LR2021 BUSY and IRQ semantics; do not invent or infer register commands from this packet.')
p('Before disabling a radio, stop its SPI activity, set all controller outputs toward that radio to high impedance with no pull-up, then take EN low. This avoids powering an OFF radio through GPIO protection structures. Deinitializing an SPI peripheral must actually release its pins; merely deasserting CS is insufficient.')
sub('RF tests after electrical tests')
p('Attach the correct antenna or suitable RF load to every actively transmitting port before transmitting. Begin at low power, verify each radio independently, then measure receiver performance with the neighboring transmitter on and off. The board does not promise simultaneous same-band transmit/receive operation. Keep external antenna cables from pulling modules out of their sockets; socket friction is not cable strain relief.')
page();title('06 | Source register')
p('Primary documents underpin the pinout and footprint decisions. Source page updates do not automatically validate this board. Manufacturer artwork is referenced rather than redistributed.')
for sid,tt,url in sources:
 story.append(para(f'<b>{sid}.</b> {html.escape(tt)}<br/><font size="7.5">{html.escape(url)}</font>','SmallX'))
p('Electrical/mechanical details derive from the listed manufacturer documentation or explicitly labeled design choices. Availability, factory revisions and assembly acceptance still require confirmation at order time.')

def footer(cv,doc):
 cv.setStrokeColor(colors.HexColor('#d2dce2'));cv.line(42,40,A4[0]-42,40);cv.setFont('Helvetica',8);cv.setFillColor(MUT);cv.drawString(42,27,'REV A | ENGINEERING REVIEW REQUIRED');cv.drawRightString(A4[0]-42,27,str(doc.page))
doc=SimpleDocTemplate(str(ROOT/'docs/Engineering_and_Order_Packet.pdf'),pagesize=A4,rightMargin=42,leftMargin=42,topMargin=38,bottomMargin=55,title='Dual LR2021 Carrier Rev A - Engineering and Order Packet',author='Prepared for Lane Araujo')
doc.build(story,onFirstPage=footer,onLaterPages=footer)

# Text handoff: concise enough to send directly to a full-service assembler.
rfq='''Subject: Engineering-review and turnkey-PCBA quote request - Dual LR2021 Carrier Rev A

This is an unreleased prototype. Please quote and review; do not fabricate until written release.

Base scope: fabricate the included 100 x 70 mm, 4-layer, 1.6 mm FR-4 carrier and populate ALL 26 carrier components. This includes 20 SMT parts and SIX through-hole FEMALE socket strips. The customer must not need to solder anything. All parts are top-side. Please explicitly confirm THT/manual assembly capability, socket sourcing, and complete BOM coverage.

Optional truly complete hardware scope: also supply TWO pre-headered Waveshare Core2021-HF-M (SKU 34523) radio modules and ONE pre-headered Waveshare RP2040-Plus-M 4MB (SKU 20808) controller. Insert them as shown after inspection. Quote suitable included-band antennas/cables and a USB-C DATA cable separately. No battery is requested. No radio application firmware is supplied by this package; quote firmware/test work separately rather than claiming a functioning radio network.

Required before manufacturing approval:
- Independent engineering review, native KiCad import/ERC/DRC, and CAM/DFM review.
- Verify photo-derived radio pin orientation against actual HF-M modules, controller revision/power capability, and socket/male-header fit.
- Review neutral centroids and package rotations, especially TPS22919 pin 1.
- Confirm all passive and socket MPN availability. TDK CGA4J3X5R1A106K125AB is specified for the bulk capacitor; submit any proposed substitute MPN/datasheet for approval.
- Confirm total price, minimum prototype quantity, lead time, procurement exceptions, inspection, and first-article test scope.

Please include bare-board electrical test and assembled visual inspection. PCB acceptance or a DFM report is not a substitute for circuit/firmware/RF validation. Build the smallest practical first-article lot after release, not a volume batch.

Coordinates: mm, lower-left origin, +X right, +Y up. PTH and NPTH drills are separate. See assembly_drawing.pdf, fabrication_requirements.txt and Engineering_and_Order_Packet.pdf.
'''
(ROOT/'assembly/RFQ_to_assembler.txt').write_text(rfq)
(ROOT/'manufacturing/fabrication_requirements.txt').write_text('''UNRELEASED PROTOTYPE - ENGINEERING APPROVAL REQUIRED BEFORE FABRICATION

Size: 100.00 x 70.00 mm, rectangular routed outline.
Stack: 4 copper layers, top-to-bottom F.Cu / In1.Cu GND / In2.Cu / B.Cu GND.
FR-4, Tg >=150 C, 1.60 mm nominal finished thickness (vendor tolerance to be approved).
35 um nominal finished outer copper; inner copper >=18 um. Vendor standard symmetric stackup subject to engineering approval. No RF controlled-impedance requirement.
Finish ENIG, green solder mask both sides, white top silkscreen.
Minimum nominal trace width 0.20 mm, copper clearance 0.20 mm. Power traces 0.25 mm.
Plated socket holes 1.04 mm FINISHED diameter, 1.85 mm copper pads.
Through vias 0.30 mm finished drill, 0.60 mm copper pad. Tent both sides.
Four 3.20 mm NPTH mounting holes. Never plate these holes.
PTH / NPTH drill files are separate. No slots. No buried/blind vias. No via-in-pad.
Require bare-board electrical test and external CAM/DFM review.
Do not remove isolated RF/no-connect pads or modify ground clearances without approval.
Only TOP is assembled. 20 SMT parts + six THT socket strips. Test pads are bare PCB features.
Do not authorize assembly from Gerbers alone; include BOM, placement lists and assembly drawing.
Neutral Gerbers use millimeters, 4.6 absolute coordinates, lower-left origin, positive copper.
Neutral centroids use millimeters, lower-left origin, CCW rotation. Check pin1 against drawing.

The snapshot is not native-KiCad-validated. Do not mix these outputs with a partially regenerated design. Open/check/refill in native KiCad, compare all nets, and regenerate the complete set after any change.
''')
(ROOT/'manufacturing/DO_NOT_ORDER_WITHOUT_REVIEW.txt').write_text('This manufacturing snapshot is a prototype, not released for blind ordering. The engineering review gates in docs/Engineering_and_Order_Packet.pdf must be closed first. Native KiCad ERC/DRC and physical validation were not run. Read assembly/RFQ_to_assembler.txt.\n')
(ROOT/'firmware/pinmap.h').write_text('''#pragma once
/* Dual LR2021 Carrier Rev A. Pin mapping only, NOT an application/driver.
 * GPIO numbers below are RP2040 GPIOs, NOT physical socket numbers.
 * Both radios default OFF. Prevent GPIO back-powering before disabling EN.
 */
#define RADIO_A_SPI_INSTANCE 1
#define RADIO_A_MISO_GPIO 8
#define RADIO_A_CS_GPIO 9
#define RADIO_A_SCK_GPIO 10
#define RADIO_A_MOSI_GPIO 11
#define RADIO_A_BUSY_GPIO 12
#define RADIO_A_IRQ_GPIO 13
#define RADIO_A_RESET_GPIO 14
#define RADIO_A_POWER_EN_GPIO 6
#define RADIO_B_SPI_INSTANCE 0
#define RADIO_B_MISO_GPIO 16
#define RADIO_B_CS_GPIO 17
#define RADIO_B_SCK_GPIO 18
#define RADIO_B_MOSI_GPIO 19
#define RADIO_B_BUSY_GPIO 20
#define RADIO_B_IRQ_GPIO 21
#define RADIO_B_RESET_GPIO 22
#define RADIO_B_POWER_EN_GPIO 26
''')
(ROOT/'firmware/README.md').write_text('''# Firmware scope

Only a reviewed-against-model pin allocation is included. There is NO completed radio driver, USB modem firmware, mesh stack, UF2, or physical test claim.

Use the vendor-supported LR2021 driver and verify SPI pin multiplexing against the actual RP2040 SDK. Radio A uses SPI1; B uses SPI0. EN is active high; both EN lines have external 100k pull-downs. All module-facing outputs must be high-impedance with no pull-ups while that module is off. USB power budgeting/enumeration/suspend must be handled before switching on extra loads. See the engineering packet for the full bring-up contract.

Do not assume stock single-radio firmware knows about these power enables or pin assignments.
''')
(ROOT/'verification/RELEASE_GATES.md').write_text('''# Unclosed release gates

- [ ] Independent electrical review of complete schematic and actual module revisions.
- [ ] Radio top-view contact mapping verified against actual pre-headered HF-M module, not only the underside photo. Verify RF header-pad connection/jumper state and any socket-stub effect.
- [ ] Samtec sockets physically mate to actual header tails and seated modules clear carrier parts.
- [ ] Controller regulator revision, USB input policy, current budget and thermal behavior verified.
- [ ] Native KiCad import, library consistency, ERC, refill, DRC and netlist comparison performed.
- [ ] Independent CAM viewer/DFM review of every copper/mask/paste/drill layer.
- [ ] Assembly provider confirms all six female sockets, THT process, component rotations and procurement.
- [ ] All component sourcing and any substitutes resolved with approved exact MPNs.
- [ ] First article: unpowered checks, controlled power, GPIO/USB/radio-driver test, both radios independently.
- [ ] Coexistence/desensitization and desired throughput measured, not assumed.

Custom geometry and export checks are NOT native CAD/ERC/DRC, certification or first-article results.
''')
(ROOT/'source/requirements.txt').write_text('numpy\nscipy\nshapely>=2.1\nPillow\nreportlab\nPyMuPDF\n')
(ROOT/'README_FIRST.md').write_text('''# Dual LR2021 Socketed Carrier - Rev A

## ENGINEERING REVIEW REQUIRED - NOT RELEASED FOR BLIND ORDERING

This is an actual generated prototype design package, not a tested or independently approved production release. Fabrication and assembly files are provided for review and quotation. Native KiCad import/ERC/DRC and physical fit/electrical/RF tests could not be run here. Do not treat a geometric PASS as proof that a manufactured system will work.

## Start here

1. Open `docs/Engineering_and_Order_Packet.pdf` and `assembly/assembly_drawing.pdf`.
2. Confirm the exact module choice: 2 x Waveshare Core2021-HF-M (34523), 1 x Waveshare RP2040-Plus-M 4MB (20808), all pre-headered. The sockets are NOT generic to all LR2021 or RP2040 boards.
3. Have a qualified reviewer close `verification/RELEASE_GATES.md` and run native KiCad and independent CAM checks.
4. Send the package with `assembly/RFQ_to_assembler.txt` to a full-service PCB ASSEMBLY supplier. Gerbers alone buy a bare board, not a finished carrier.

## No owner soldering

The factory solders all 20 SMT parts and all SIX female socket strips. Base delivery leaves only plugging in the pre-headered modules. For completely populated delivery, request the optional module procurement/insertion scope too. This package includes a pin map but NOT radio application firmware; assembled hardware is not the same as a working USB radio or mesh network.

## Files

- `source/`: KiCad board + schematic + embedded/local libraries, netlist and reproducible Python generator/model.
- `manufacturing/gerbers/`: four copper layers, mask, top paste, top silkscreen, profile and separate PTH/NPTH drills.
- `assembly/`: carrier BOM, SMT/THT/all placement lists, optional module BOM, assembly drawing and RFQ.
- `docs/`: electrical schematic PDF, layer views, exact terminal map, source register and engineering packet.
- `verification/`: custom geometric/export readback results and the outstanding release gates.
- `firmware/`: pin allocation and software requirements only.

## Procurement

The BOM contains exact MPNs, including TDK CGA4J3X5R1A106K125AB for the 10uF bulk capacitors. All part availability, module revisions and any proposed substitutes require confirmation at quote time. There are no fabricated supplier IDs, stock reservations or accepted quotes in this package.

## Reproduction

Install `source/requirements.txt`, then run `python source/build_design.py` (cached routing) and `python source/build_package.py`. Run `python source/check_exports.py` for export verification. Use `--reroute` on build_design.py if placement/connectivity changes. Never reuse cached routing after moving pads. Generator changes require regenerating and rechecking the entire package.

Board/net geometry was created programmatically, not exported by native KiCad. Exact filled plane polygons are included as a snapshot; a native refill may change geometry. After native review, regenerate the full manufacturing package from the reviewed project rather than mixing exports.
''')
# Render final PDFs to inspect in ordinary image viewer. Only a selected preview is copied to deliverables.
renders=ROOT.parent/'_lr2021_review';renders.mkdir(exist_ok=True)
for rel in ['assembly/assembly_drawing.pdf','docs/schematic.pdf','docs/Engineering_and_Order_Packet.pdf']:
 d=fitz.open(ROOT/rel)
 for i,pag in enumerate(d):
  pix=pag.get_pixmap(matrix=fitz.Matrix(1.25,1.25),alpha=False);pix.save(renders/(Path(rel).stem+f'_{i+1}.png'))
# Actual layout preview is separate from the assembly documentation.
d=fitz.open(ROOT/'docs/board_layers.pdf');d[0].get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(ROOT/'docs/PCB_top_preview.png')
print('Package documents created. Review PDF renders, then run check_exports.py before archiving.')
