#!/usr/bin/env python3
"""Read back generated Gerber/drill/native text and compare to model.
An independent parser implementation, NOT an independent engineering review or native CAM/DRC.
"""
from __future__ import annotations
from pathlib import Path
import json,re,csv,math,hashlib
from collections import defaultdict,Counter
from xml.etree import ElementTree as ET
from shapely.geometry import Point,LineString,Polygon,box
from shapely.ops import unary_union
from shapely import wkt
R=Path(__file__).resolve().parents[1];M=json.loads((R/'source/design_model.json').read_text());H=M['height'];W=M['width']
errors=[];details={}
def assertok(condition,msg):
 if not condition:errors.append(msg)
def rot(x,y,a):
 a=math.radians(-a);return x*math.cos(a)-y*math.sin(a),x*math.sin(a)+y*math.cos(a)
def padgeom(p,e=0):
 if p['shape']=='circle':return Point(p['x'],p['y']).buffer(p['sx']/2+e,quad_segs=32)
 a=[]
 for x,y in [(-p['sx']/2-e,-p['sy']/2-e),(p['sx']/2+e,-p['sy']/2-e),(p['sx']/2+e,p['sy']/2+e),(-p['sx']/2-e,p['sy']/2+e)]:
  x,y=rot(x,y,p['angle']);a.append((x+p['x'],y+p['y']))
 return Polygon(a)

def readgerber(p):
 aps={};ap=None;x=y=None;region=None;pol='D';geom=Polygon();pending=[];flashes=[]
 def flush():
  nonlocal geom,pending
  if pending:
   g=unary_union(pending);geom=geom.union(g) if pol=='D' else geom.difference(g);pending=[]
 def emit(g):pending.append(g)
 for ln in p.read_text().splitlines():
  ln=ln.strip()
  a=re.fullmatch(r'%ADD(\d+)([CR]),([0-9.X]+)\*%',ln)
  if a:aps[int(a[1])]=(a[2],[float(s) for s in a[3].split('X')]);continue
  a=re.fullmatch(r'%LP([DC])\*%',ln)
  if a:flush();pol=a[1];continue
  a=re.fullmatch(r'D(\d+)\*',ln)
  if a:ap=aps[int(a[1])];continue
  if ln=='G36*':region=[];continue
  if ln=='G37*':
   assert region is not None and len(region)>=3
   emit(Polygon(region));region=None;continue
  a=re.fullmatch(r'X(-?\d+)Y(-?\d+)D0([123])\*',ln)
  if a:
   xx=int(a[1])/1e6;yy=H-int(a[2])/1e6;d=int(a[3])
   if region is not None:region.append((xx,yy))
   elif d==1:
    assert ap and ap[0]=='C','Noncircular stroke aperture';emit(LineString([(x,y),(xx,yy)]).buffer(ap[1][0]/2,quad_segs=32))
   elif d==3:
    assert ap
    if ap[0]=='C':g=Point(xx,yy).buffer(ap[1][0]/2,quad_segs=32)
    else:sx,sy=ap[1];g=box(xx-sx/2,yy-sy/2,xx+sx/2,yy+sy/2)
    flashes.append((xx,yy,ap));emit(g)
   x,y=xx,yy;continue
  assertok(ln.startswith(('G04','%FSL','%MOMM','%TF.','G01','M02')) or not ln,f'Unsupported Gerber syntax in {p.name}: {ln}')
 flush();return geom,flashes

for layer in M['layers']:
 f=R/'manufacturing/gerbers'/f'Dual_LR2021-RevA-{layer.replace(".","_")}.gbr'
 actual,flashes=readgerber(f);gs=[]
 if layer in ['In1.Cu','B.Cu']:gs.append(wkt.loads(json.loads((R/'source/planes.json').read_text())[layer]))
 gs.extend(padgeom(p) for p in M['pads'] if layer=='F.Cu' or p['kind']=='thru_hole')
 gs.extend(Point(v['x'],v['y']).buffer(v['diameter']/2,quad_segs=32) for v in M['vias'])
 gs.extend(LineString(t['points']).buffer(t['width']/2,quad_segs=32) for t in M['tracks'] if t['layer']==layer)
 exp=unary_union(gs);diff=actual.symmetric_difference(exp).area
 assertok(diff<.005,f'{layer} exported copper differs from expected by {diff:.6f} sq mm')
 assertok(actual.is_valid,f'{layer} invalid readback polygons')
 details[layer]={'symmetric_difference_area_mm2':diff,'readback_valid':actual.is_valid,'flash_count':len(flashes)}
for layer in ['F_Mask','B_Mask','F_Paste']:
 actual,flashes=readgerber(R/'manufacturing/gerbers'/f'Dual_LR2021-RevA-{layer}.gbr')
 selected=[p for p in M['pads'] if (layer=='F_Mask' or (layer=='B_Mask' and p['kind']=='thru_hole') or (layer=='F_Paste' and p['kind']=='smd' and not p['ref'].startswith('TP')))]
 exp=unary_union([padgeom(p,.05 if 'Mask' in layer else 0) for p in selected]);diff=actual.symmetric_difference(exp).area
 assertok(diff<.002,f'{layer} difference {diff:.6f} sq mm');assertok(len(flashes)==len(selected),f'{layer} flash count mismatch')
 details[layer]={'symmetric_difference_area_mm2':diff,'opening_count':len(flashes)}
actual,_=readgerber(R/'manufacturing/gerbers/Dual_LR2021-RevA-F_SilkS.gbr');exp=wkt.loads((R/'source/silkscreen.wkt').read_text());diff=actual.symmetric_difference(exp).area
assertok(diff<.005,f'Silkscreen difference {diff}');details['F_SilkS']={'symmetric_difference_area_mm2':diff}
actual,_=readgerber(R/'manufacturing/gerbers/Dual_LR2021-RevA-Edge_Cuts.gbr');exp=LineString([(0,0),(W,0),(W,H),(0,H),(0,0)]).buffer(.025,quad_segs=32);diff=actual.symmetric_difference(exp).area
assertok(diff<.001,f'Edge difference {diff}');details['profile']={'closed_rectangle_mm':[W,H],'symmetric_difference_area_mm2':diff}

def readdrill(p):
 tools={};tool=None;out=[]
 for ln in p.read_text().splitlines():
  a=re.fullmatch(r'T(\d+)C([0-9.]+)',ln)
  if a:tools[int(a[1])]=float(a[2]);continue
  a=re.fullmatch(r'T(\d+)',ln)
  if a:tool=tools[int(a[1])];continue
  a=re.fullmatch(r'X(-?[0-9.]+)Y(-?[0-9.]+)',ln)
  if a:out.append((round(float(a[1]),3),round(H-float(a[2]),3),round(tool,3)))
 return Counter(out)
for kind in ['PTH','NPTH']:
 actual=readdrill(R/'manufacturing/gerbers'/f'Dual_LR2021-RevA-{kind}.drl')
 exp=Counter((round(x,3),round(y,3),round(d,3)) for x,y,d in ([(p['x'],p['y'],p['drill']) for p in M['pads'] if p['drill']]+[(v['x'],v['y'],v['drill']) for v in M['vias']] if kind=='PTH' else [(h['x'],h['y'],h['drill']) for h in M['holes']]))
 assertok(actual==exp,f'{kind} drill mismatch');details[kind]={'hole_count':sum(actual.values()),'diameter_counts':dict(Counter(str(d) for (x,y,d),count in actual.items() for _ in range(count)))}
# General S-expression parser validates balanced syntax and inspects actual embedded data.
def sexpr(s):
 tokens=re.findall(r'"(?:\\.|[^"\\])*"|[()]|[^\s()]+',s);stack=[];root=None
 for tok in tokens:
  if tok=='(':
   el=[]
   if stack:stack[-1].append(el)
   else:
    if root is not None:raise ValueError('Multiple roots')
    root=el
   stack.append(el)
  elif tok==')':
   if not stack:raise ValueError('Extra close parenthesis')
   stack.pop()
  else:
   if not stack:raise ValueError('Token outside expression')
   stack[-1].append(json.loads(tok) if tok.startswith('"') else tok)
 if stack:raise ValueError('Unclosed expression')
 return root

def kids(a,key):return [x for x in a if isinstance(x,list) and x and x[0]==key]
def kid(a,key):return next(iter(kids(a,key)),None)
syntax=[]
for f in list((R/'source').glob('*.kicad_*'))+list((R/'source/Carrier.pretty').glob('*.kicad_mod')):
 if f.suffix=='.kicad_pro':json.loads(f.read_text());continue
 try:a=sexpr(f.read_text());syntax.append(f.name)
 except Exception as e:errors.append(f'{f.name} syntax: {e}')
b=sexpr((R/'source/Dual_LR2021_Carrier.kicad_pcb').read_text());nf={x[1]:x[2] for x in kids(b,'net')};bp={}
for fp in kids(b,'footprint'):
 ref=next((a[2] for a in kids(fp,'fp_text') if a[1]=='reference'),None)
 if ref and ref.startswith('H'):continue
 at=kid(fp,'at');fx,fy=map(float,at[1:3]);a=float(at[3]) if len(at)>3 else 0
 for pd in kids(fp,'pad'):
  at=kid(pd,'at');x,y=map(float,at[1:3]);x,y=rot(x,y,a);net=kid(pd,'net');bp[(ref,pd[1])]=(fx+x,fy+y,net[2],tuple(float(z) for z in kid(pd,'size')[1:3]))
assertok(len(bp)==len(M['pads']),'Native PCB pad count mismatch')
for p in M['pads']:
 a=bp.get((p['ref'],p['num']))
 assertok(a is not None and math.hypot(a[0]-p['x'],a[1]-p['y'])<1e-5 and a[2]==p['net'] and a[3]==(p['sx'],p['sy']),f'Native PCB pad mismatch: {p["ref"]}.{p["num"]}')
assertok(len(kids(b,'via'))==len(M['vias']),'Native PCB via count mismatch')
assertok(len(kids(b,'segment'))==sum(len(t['points'])-1 for t in M['tracks']),'Native PCB track segment count mismatch')
# Read actual schematic wires and labels, then compare every symbol terminal.
s=sexpr((R/'source/Dual_LR2021_Carrier.kicad_sch').read_text());libs={x[1]:x for x in kids(kid(s,'lib_symbols'),'symbol')}
labels={tuple(map(float,kid(a,'at')[1:3])):a[1] for a in kids(s,'label')};ncs={tuple(map(float,kid(a,'at')[1:3])) for a in kids(s,'no_connect')}
wires={}
for a in kids(s,'wire'):
 pts=kid(a,'pts');xy=[tuple(map(float,x[1:3])) for x in kids(pts,'xy')];wires[xy[0]]=xy[1];wires[xy[1]]=xy[0]
schterms={}
for a in kids(s,'symbol'):
 at=kid(a,'at');cx,cy=map(float,at[1:3]);ref=next(v[2] for v in kids(a,'property') if v[1]=='Reference');li=libs[kid(a,'lib_id')[1]]
 for ss in kids(li,'symbol'):
  for pin in kids(ss,'pin'):
   at=kid(pin,'at');x,y=map(float,at[1:3]);pt=(cx+x,cy-y);num=kid(pin,'number')[1]
   # compare decimal float endpoints with a small tolerance; labels are unique.
   find=lambda coll: next((z for z in coll if math.hypot(z[0]-pt[0],z[1]-pt[1])<1e-7),None)
   nc=find(ncs)
   if nc is not None:schterms[(ref,num)]='NC'
   else:
    wirept=find(wires)
    if wirept is None:errors.append(f'Schematic unconnected pin {ref}.{num}');continue
    far=wires[wirept];label=next((v for xy,v in labels.items() if math.hypot(xy[0]-far[0],xy[1]-far[1])<1e-7),None);schterms[(ref,num)]=label
assertok(len(schterms)==len(M['pads']),'Schematic terminal count mismatch')
for p in M['pads']:assertok(schterms.get((p['ref'],p['num']))==('NC' if p['net'].startswith('NC_') else p['net']),f'Schematic vs board mismatch {p["ref"]}.{p["num"]}')
xml=ET.parse(R/'source/Dual_LR2021_Carrier.net').getroot();xn={}
for n in xml.find('nets'):
 for nd in n:xn[(nd.attrib['ref'],nd.attrib['pin'])]=n.attrib['name']
for p in M['pads']:
 if not p['net'].startswith('NC_'):assertok(xn.get((p['ref'],p['num']))==p['net'],f'XML netlist mismatch {p["ref"]}.{p["num"]}')
with (R/'assembly/BOM_carrier.csv').open() as f:br=list(csv.DictReader(f))
with (R/'assembly/placements_all.csv').open() as f:pr=list(csv.DictReader(f))
expected={c['ref'] for c in M['components'] if c['kind'] in ['smd','through_hole']}
actual=set(r for row in br for r in row['Designators'].split(','))
assertok(actual==expected,'BOM reference coverage mismatch');assertok({row['Designator'] for row in pr}==expected,'Placement reference coverage mismatch');assertok(sum(int(row['Quantity']) for row in br)==len(expected),'BOM quantities mismatch')
# Grounds are checked as separate polygon objects; cannot hide an isolated island in a MultiPolygon.
planes={n:wkt.loads(x) for n,x in json.loads((R/'source/planes.json').read_text()).items()}
for n,g in planes.items():assertok(g.geom_type=='Polygon' and g.is_valid,f'{n} contains separated plane polygons or invalid geometry')
# RF-contact no-connect isolation: no native traces touch the net, and every NC net has one terminal.
netcounts=Counter(p['net'] for p in M['pads'])
for n,count in netcounts.items():
 if n.startswith('NC_'):assertok(count==1 and not any(t['net']==n for t in M['tracks']),f'NC net unexpectedly routed {n}')
# Only engineering-review documentation is present; there is no fake native PASS.
details['native_text']={'balanced_files':syntax,'PCB_pad_count':len(bp),'schematic_pin_count':len(schterms),'XML_connected_pins':len(xn),'native_import_ERC_DRC':'NOT RUN'}
details['assembly']={'BOM_fitted_quantity':sum(int(row['Quantity']) for row in br),'placement_rows':len(pr),'SMT_count':sum(c['kind']=='smd' for c in M['components']),'THT_count':sum(c['kind']=='through_hole' for c in M['components'])}
result={'status':'PASS' if not errors else 'FAIL','scope':'Independent readback implementation compared to the same intended design model; not independent electrical review, native KiCad import/ERC/DRC, certified CAM or physical testing.','errors':errors,'details':details}
(R/'verification/export_readback.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'errors':errors,'details':details},indent=2))
if errors:raise SystemExit(2)
# Inventory with hashes. Regenerate after edits, never hand-edit the checksums.
manifest=[]
for f in sorted(R.rglob('*')):
 if f.is_file() and f.name not in ['SHA256SUMS.txt','package_manifest.json'] and f.suffix!='.zip':manifest.append({'path':str(f.relative_to(R)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(R/'verification/package_manifest.json').write_text(json.dumps(manifest,indent=2))
(R/'SHA256SUMS.txt').write_text(''.join(f'{r["sha256"]}  {r["path"]}\n' for r in manifest))
