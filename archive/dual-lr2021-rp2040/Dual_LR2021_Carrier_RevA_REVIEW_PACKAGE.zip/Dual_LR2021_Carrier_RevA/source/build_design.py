#!/usr/bin/env python3
"""Reproducible prototype carrier layout and neutral manufacturing exports.
Requires Python 3.10+, numpy, scipy, shapely>=2.1, Pillow.
NOT a substitute for native ECAD ERC/DRC, assembler DFM, or first-article testing.
"""
from __future__ import annotations
import json, math, uuid, heapq, time, csv, sys, os, re
from pathlib import Path
from collections import defaultdict
import numpy as np
from PIL import Image,ImageDraw
from scipy.ndimage import binary_dilation
from shapely.geometry import Point, Polygon, LineString, box, MultiPolygon
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles

ROOT=Path(__file__).resolve().parents[1]
W,H=100.,70.
CLEAR=.20
GRID=.10
LAYERS=['F.Cu','In1.Cu','In2.Cu','B.Cu']
ROUTE_LAYERS=['F.Cu','In2.Cu']
UUID_NS=uuid.UUID('c942d004-4981-43ee-b93f-fecf26a28eef')
def uid(s): return str(uuid.uuid5(UUID_NS,s))
def q(s): return json.dumps(str(s),ensure_ascii=False)
def rnd(x): return round(float(x),6)
def rot(x,y,angle):
 a=math.radians(-angle);return (x*math.cos(a)-y*math.sin(a), x*math.sin(a)+y*math.cos(a))

components=[]; pads=[]; tracks=[]; vias=[]; silks=[]; holes=[]; keepouts=[]; planes={}
def component(ref,value,footprint,x,y,angle=0,mpn='',manufacturer='',description='',kind='smd'):
 c=dict(ref=ref,value=value,footprint=footprint,x=x,y=y,angle=angle,mpn=mpn,manufacturer=manufacturer,description=description,kind=kind,pads=[],uuid=uid('sym/'+ref))
 components.append(c); return c

def pad(c,num,x,y,sx,sy,net,kind='smd',drill=0,shape='rect'):
 dx,dy=rot(x,y,c['angle']);wx,wy=c['x']+dx,c['y']+dy
 n=net if net else f'NC_{c["ref"]}_{num}'
 p=dict(ref=c['ref'],num=str(num),local_x=x,local_y=y,x=rnd(wx),y=rnd(wy),sx=sx,sy=sy,angle=c['angle'],net=n,kind=kind,drill=drill,shape=shape)
 c['pads'].append(p);pads.append(p);return p

def header(ref,n,x,y,angle,nets,desc):
 c=component(ref,f'SSW-1{n:02d}-01-G-S',f'SSW_1x{n:02d}_P2.54_Vertical',x,y,angle,f'SSW-1{n:02d}-01-G-S','Samtec',desc,'through_hole')
 for i,net in enumerate(nets):pad(c,i+1,0,2.54*i,1.85,1.85,net,'thru_hole',1.04,'rect' if i==0 else 'circle')
 return c

def passive(ref,value,x,y,net1,net2,mpn,desc,angle=0,cap=False):
 fp='C_0805_2012' if cap else 'R_0805_2012'
 c=component(ref,value,fp,x,y,angle,mpn,('TDK' if mpn.startswith('CGA') else 'Murata') if cap else 'Yageo',desc)
 for num,dx,n in [(1,-.95,net1),(2,.95,net2)]:pad(c,num,dx,0,1.15,1.45,n)
 return c

def tp(ref,net,x,y):
 c=component(ref,net,'TestPad_D1.4',x,y,0,'','',f'Bare PCB probe pad: {net}','testpoint')
 pad(c,1,0,0,1.4,1.4,net,shape='circle');return c

# MCU viewed from TOP, USB-C toward the upper board edge. J1 local 1=MCU 1.
# J2 local 1=MCU 40; J2 local 20=MCU 21. All are separate socket strips.
left=['','','GND','','','','','GND','A_EN','','A_MISO_HOST','A_CS','GND','A_SCK_HOST','A_MOSI_HOST','A_BUSY','A_IRQ','GND','A_RESET','']
right=['','','GND','','+3V3','','','GND','','B_EN','','B_RESET','GND','B_IRQ','B_BUSY','B_MOSI_HOST','B_SCK_HOST','GND','B_CS','B_MISO_HOST']
header('J1',20,41.11,1.60,0,left,'MCU left socket; local 1=physical 1 (GP0), local 20=physical 20 (GP15)')
header('J2',20,58.89,1.60,0,right,'MCU right socket; local 1=physical 40 (VBUS), local 20=physical 21 (GP16)')
# Core2021 TOP view is mirrored from the vendor's underside pin-label photograph.
# Antenna connector end points LEFT for A, RIGHT for B. RF contacts are isolated.
irqA=['','GND','A_IRQ','','','','GND','A_3V3']
spiA=['','GND','A_CS','A_SCK','A_MOSI','A_MISO','A_RESET','A_BUSY']
irqB=['','GND','B_IRQ','','','','GND','B_3V3']
spiB=['','GND','B_CS','B_SCK','B_MOSI','B_MISO','B_RESET','B_BUSY']
header('J3',8,9.11,48.62,90,irqA,'Radio A DIO/power row; pin 1 = unused 2.4-GHz antenna contact')
header('J4',8,9.11,33.38,90,spiA,'Radio A SPI row; pin 1 = unused sub-GHz antenna contact')
header('J5',8,90.89,33.38,270,irqB,'Radio B DIO/power row; pin 1 = unused 2.4-GHz antenna contact')
header('J6',8,90.89,48.62,270,spiB,'Radio B SPI row; pin 1 = unused sub-GHz antenna contact')

# SC70-6 footprints follow TI DCK0006A: 2.2-mm row centers, .65-mm pitch.
for k,(r,x,y,rail,en) in enumerate([('U1',31.,20.,'A_3V3','A_EN'),('U2',69.,20.,'B_3V3','B_EN')]):
 c=component(r,'TPS22919DCKR','SC70_6_DCK0006A',x,y,0,'TPS22919DCKR','Texas Instruments','Active-high, slow-rise radio power switch; QOD tied to output')
 for pno,dx,dy,n in [(1,-1.1,-.65,'+3V3'),(2,-1.1,0,'GND'),(3,-1.1,.65,en),(4,1.1,.65,''),(5,1.1,0,rail),(6,1.1,-.65,rail)]:pad(c,pno,dx,dy,.90,.40,n)
 passive(f'R{k+1}','100k',x-4,y+3,en,'GND','RC0805FR-07100KL','Power enable pull-down, 1%, 0.125 W')
 passive(f'C{k+1}','1uF',x-3,y-4,'+3V3','GND','GRM21BR71A105KA01L','Input bypass, 10 V, X7R, +/-10%',cap=True)

# Socket-local capacitors, output-referenced pulls, source damping.
passive('C3','100nF',27.5,52.5,'A_3V3','GND','GRM21BR71C104KA01L','Radio A bypass, 16 V, X7R, +/-10%',cap=True)
passive('C4','10uF',31.5,55.5,'A_3V3','GND','CGA4J3X5R1A106K125AB','Radio A bulk, 10 V, X5R, +/-10%',cap=True)
passive('C5','100nF',72.5,29.0,'B_3V3','GND','GRM21BR71C104KA01L','Radio B bypass, 16 V, X7R, +/-10%',cap=True)
passive('C6','10uF',68.5,26.0,'B_3V3','GND','CGA4J3X5R1A106K125AB','Radio B bulk, 10 V, X5R, +/-10%',cap=True)
passive('R3','10k',13.0,27.0,'A_CS','A_3V3','RC0805FR-0710KL','Radio A chip select pull-up to switched rail')
passive('R4','10k',25.0,27.0,'A_RESET','A_3V3','RC0805FR-0710KL','Radio A reset pull-up to switched rail')
passive('R5','10k',87.0,55.0,'B_CS','B_3V3','RC0805FR-0710KL','Radio B chip select pull-up to switched rail')
passive('R6','10k',75.0,55.0,'B_RESET','B_3V3','RC0805FR-0710KL','Radio B reset pull-up to switched rail')
passive('R7','33R',37.0,34.62,'A_SCK','A_SCK_HOST','RC0805FR-0733RL','SPI1 clock source damping')
passive('R8','33R',37.0,37.16,'A_MOSI','A_MOSI_HOST','RC0805FR-0733RL','SPI1 MOSI source damping')
passive('R9','33R',23.0,37.0,'A_MISO','A_MISO_HOST','RC0805FR-0733RL','Radio A MISO source damping')
passive('R10','33R',63.0,42.24,'B_SCK_HOST','B_SCK','RC0805FR-0733RL','SPI0 clock source damping')
passive('R11','33R',63.0,39.70,'B_MOSI_HOST','B_MOSI','RC0805FR-0733RL','SPI0 MOSI source damping')
passive('R12','33R',79.0,45.0,'B_MISO_HOST','B_MISO','RC0805FR-0733RL','Radio B MISO source damping')
for args in [('TP1','+3V3',62.,12.),('TP2','GND',66.,12.),('TP3','A_3V3',21.,57.5),('TP4','B_3V3',79.,25.),('TP5','A_BUSY',32.,43.),('TP6','A_IRQ',32.,47.),('TP7','B_BUSY',68.,43.),('TP8','B_IRQ',68.,47.)]:tp(*args)

for i,(x,y) in enumerate([(5.,5.),(95.,5.),(5.,65.),(95.,65.)],1):holes.append(dict(ref=f'H{i}',x=x,y=y,drill=3.2))
# Copper keepout surrounds each otherwise isolated RF pad; no transmission lines.
for p in pads:
 if p['ref'] in ['J3','J4','J5','J6'] and p['num']=='1':keepouts.append(dict(x=p['x'],y=p['y'],r=1.6,reason='RF contact; no carrier routing'))

def padshape(p,extra=0):
 x,y=p['x'],p['y']
 if p['shape']=='circle':return Point(x,y).buffer(p['sx']/2+extra,quad_segs=12)
 sx,sy=p['sx']/2,p['sy']/2
 pts=[]
 for dx,dy in [(-sx,-sy),(sx,-sy),(sx,sy),(-sx,sy)]:
  rx,ry=rot(dx,dy,p['angle']);pts.append((x+rx,y+ry))
 return Polygon(pts).buffer(extra,quad_segs=6) if extra else Polygon(pts)

def layers_for(p):return LAYERS if p['kind']=='thru_hole' else ['F.Cu']

def geom_item(t):return LineString(t['points']).buffer(t['width']/2,quad_segs=8)
def viashape(v,extra=0):return Point(v['x'],v['y']).buffer(v['diameter']/2+extra,quad_segs=12)

# Ground SMT pads each get a nearby via; routed as a tiny stub before signals.
for p in list(pads):
 if p['net']!='GND' or p['kind']=='thru_hole':continue
 candidates=[(0,1.15),(0,-1.15),(1.3,0),(-1.3,0),(1.2,1.2),(-1.2,-1.2)]
 for dx,dy in candidates:
  x,y=p['x']+dx,p['y']+dy
  vg=Point(x,y).buffer(.30+.22)
  tg=LineString([(p['x'],p['y']),(x,y)]).buffer(.15+.22)
  if any(vg.intersects(padshape(op)) for op in pads if op['net']!='GND'):continue
  if any(tg.intersects(padshape(op)) for op in pads if op['net']!='GND'):continue
  vias.append(dict(x=rnd(x),y=rnd(y),diameter=.6,drill=.3,net='GND'))
  tracks.append(dict(net='GND',layer='F.Cu',width=.3,points=[(p['x'],p['y']),(rnd(x),rnd(y))]))
  break
 else: raise RuntimeError('No GND-via escape for '+p['ref'])

# Raster assisted A*: all copper is subsequently checked with exact polygon geometry.
NX=int(W/GRID)+1; NY=int(H/GRID)+1

def polygons(g):
 if g.is_empty:return []
 if g.geom_type=='Polygon':return [g]
 return [x for x in g.geoms if x.geom_type=='Polygon']

def raster(geoms):
 im=Image.new('1',(NX,NY));d=ImageDraw.Draw(im)
 for g in geoms:
  for po in polygons(g):
   xy=[(int(round(x/GRID)),int(round(y/GRID))) for x,y in po.exterior.coords]
   d.polygon(xy,fill=1)
 # holes intentionally left blocked: conservative router obstacles
 return np.array(im,dtype=bool)

def obstacles(net,width):
 out=[]
 common=[Point(h['x'],h['y']).buffer(h['drill']/2+.30+width/2) for h in holes]
 common += [Point(k['x'],k['y']).buffer(k['r']+width/2+.03) for k in keepouts]
 for layer in ROUTE_LAYERS:
  gs=list(common)
  gs += [padshape(p,CLEAR+width/2+.065) for p in pads if p['net']!=net and layer in layers_for(p)]
  gs += [geom_item(t).buffer(CLEAR+width/2+.065,quad_segs=4) for t in tracks if t['net']!=net and t['layer']==layer]
  gs += [viashape(v,CLEAR+width/2+.065) for v in vias if v['net']!=net]
  ar=raster(gs);bd=int(math.ceil((.4+width/2)/GRID));ar[:bd,:]=1;ar[-bd:,:]=1;ar[:,:bd]=1;ar[:,-bd:]=1
  out.append(ar)
 # Via positions must clear all F and inner signal copper. Larger safety clearance.
 gs=list(common)
 gs += [padshape(p,CLEAR+.3+.065) for p in pads if p['net']!=net]
 gs += [geom_item(t).buffer(CLEAR+.3+.065,quad_segs=4) for t in tracks if t['net']!=net]
 gs += [viashape(v,CLEAR+.3+.065) for v in vias if v['net']!=net]
 viaobs=raster(gs)
 return np.stack(out),viaobs

def solve(net,start,end,width):
 obs,vobs=obstacles(net,width)
 sx=int(round(start['x']/GRID));sy=int(round(start['y']/GRID));tx=int(round(end['x']/GRID));ty=int(round(end['y']/GRID))
 startlayers=[0,1] if start['kind']=='thru_hole' else [0]
 endlayers=[0,1] if end['kind']=='thru_hole' else [0]
 # Snap only within the connected pad, never punch an escape corridor.
 for l in startlayers:obs[l,sy,sx]=0
 for l in endlayers:obs[l,ty,tx]=0
 def key(l,y,x):return (l*NY+y)*NX+x
 def coords(k):x=k%NX;t=k//NX;return t//NY,t%NY,x
 def heuristic(y,x):
  dx=abs(tx-x);dy=abs(ty-y);return max(dx,dy)+.41421356237*min(dx,dy)
 goals={key(l,ty,tx) for l in endlayers}
 heap=[];dist={};parent={}
 for l in startlayers:
  k=key(l,sy,sx);dist[k]=0;parent[k]=-1;heapq.heappush(heap,(heuristic(sy,sx),0,k))
 dirs=[(0,1,1.),(0,-1,1.),(1,0,1.),(-1,0,1.),(1,1,1.41421356),(1,-1,1.41421356),(-1,1,1.41421356),(-1,-1,1.41421356)]
 found=None;exp=0
 while heap:
  _,g,k=heapq.heappop(heap)
  if g>dist.get(k,1e30)+1e-9:continue
  if k in goals:found=k;break
  l,y,x=coords(k);exp+=1
  if exp>450000:break
  for dy,dx,dd in dirs:
   yy=y+dy;xx=x+dx
   if xx<0 or xx>=NX or yy<0 or yy>=NY or obs[l,yy,xx]:continue
   if dx and dy and (obs[l,y,xx] or obs[l,yy,x]):continue
   preference=0.05 if (l==0 and dy and not dx) or (l==1 and dx and not dy) else 0
   ng=g+dd+preference;nk=key(l,yy,xx)
   if ng+1e-8<dist.get(nk,1e30):
    dist[nk]=ng;parent[nk]=k;heapq.heappush(heap,(ng+heuristic(yy,xx),ng,nk))
  if not vobs[y,x] and not obs[1-l,y,x]:
   nk=key(1-l,y,x);ng=g+18
   if ng<dist.get(nk,1e30):dist[nk]=ng;parent[nk]=k;heapq.heappush(heap,(ng+heuristic(y,x),ng,nk))
 if found is None:raise RuntimeError(f'Route failed {net}: {start["ref"]}.{start["num"]} -> {end["ref"]}.{end["num"]}; expansions={exp}')
 path=[];k=found
 while k!=-1:path.append(coords(k));k=parent[k]
 path.reverse()
 # Merge collinear steps. Keep exact pad centers at each end.
 segments=[];cur_l=path[0][0];pts=[(start['x'],start['y']),(path[0][2]*GRID,path[0][1]*GRID)]
 for l,y,x in path[1:]:
  if l!=cur_l:
   vx=rnd(x*GRID);vy=rnd(y*GRID)
   segments.append((cur_l,pts));vias.append(dict(x=vx,y=vy,diameter=.6,drill=.3,net=net));cur_l=l;pts=[(vx,vy)]
  else:pts.append((rnd(x*GRID),rnd(y*GRID)))
 pts.append((end['x'],end['y']));segments.append((cur_l,pts))
 for l,ps in segments:
  dedup=[]
  for pt in ps:
   pt=tuple(map(rnd,pt))
   if not dedup or pt!=dedup[-1]:dedup.append(pt)
  clean=[]
  for p in dedup:
   while len(clean)>=2:
    a,b=clean[-2],clean[-1];v=(b[0]-a[0],b[1]-a[1]);w=(p[0]-b[0],p[1]-b[1])
    if abs(v[0]*w[1]-v[1]*w[0])<1e-7 and v[0]*w[0]+v[1]*w[1]>0:clean.pop()
    else:break
   clean.append(p)
  if len(clean)>=2:tracks.append(dict(net=net,layer=ROUTE_LAYERS[l],width=width,points=clean))

bynet=defaultdict(list)
for p in pads:
 if p['net']!='GND' and not p['net'].startswith('NC_'):bynet[p['net']].append(p)
# Tight SC70 links and power first, then short series tails, then all other signals.
order=list(bynet)
def orderkey(n):
 ps=bynet[n]
 if n in ['A_3V3','B_3V3']:return (0,n)
 if n in ['A_EN','B_EN']:return (1,n)
 if n=='+3V3':return (2,n)
 if n.endswith('_HOST'):return (3,n)
 return (4,n)
route_cache=ROOT/'source'/'routed_geometry.json'
if '--reroute' not in sys.argv and route_cache.exists():
 cache=json.loads(route_cache.read_text());tracks=cache['tracks'];vias=cache['vias'];print('Loaded cached routing',flush=True)
else:
 for n in sorted(order,key=orderkey):
  ps=bynet[n];connected=[ps[0]];remaining=ps[1:]
  while remaining:
   a,b=min(((a,b) for a in connected for b in remaining),key=lambda ab:math.hypot(ab[0]['x']-ab[1]['x'],ab[0]['y']-ab[1]['y']))
   # SC70 pad escape is limited to 0.25 mm; power branches widen after escape in a later revision.
   width=.25 if n in ['+3V3','A_3V3','B_3V3'] else .20
   solve(n,a,b,width);connected.append(b);remaining.remove(b)
  print('routed',n,flush=True)
 route_cache.write_text(json.dumps(dict(tracks=tracks,vias=vias),indent=2))

# Ground plane copper with antipads and thermal relief on through-hole socket grounds.
# Real copper geometries, not image approximations. All coordinates use mm.
board_area=box(.4,.4,W-.4,H-.4)
for layer in ['In1.Cu','B.Cu']:
 remove=[];spokes=[]
 for p in pads:
  if p['kind']!='thru_hole':continue
  if p['net']!='GND':remove.append(padshape(p,.25))
  else:
   gap=.30;rad=p['sx']/2+gap
   remove.append(Point(p['x'],p['y']).buffer(rad,quad_segs=12))
   spokes += [box(p['x']-rad-.05,p['y']-.15,p['x']+rad+.05,p['y']+.15),box(p['x']-.15,p['y']-rad-.05,p['x']+.15,p['y']+rad+.05)]
 for v in vias:
  if v['net']!='GND':remove.append(viashape(v,.25))
 remove += [Point(h['x'],h['y']).buffer(h['drill']/2+.30,quad_segs=20) for h in holes]
 remove += [Point(k['x'],k['y']).buffer(k['r'],quad_segs=20) for k in keepouts]
 plane=board_area.difference(unary_union(remove))
 plane=unary_union([plane]+spokes).intersection(board_area)
 # Reinstate a no-copper disk at NPTH holes and RF keepouts after thermal spokes.
 plane=plane.difference(unary_union([Point(k['x'],k['y']).buffer(k['r'],quad_segs=20) for k in keepouts]+[Point(h['x'],h['y']).buffer(h['drill']/2+.30,quad_segs=20) for h in holes]))
 planes[layer]=plane

# Pure vector line font makes the same silkscreen export independent of external fonts.
FONT={
'A':['01110','10001','10001','11111','10001','10001','10001'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'D':['11110','10001','10001','10001','10001','10001','11110'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'F':['11111','10000','10000','11110','10000','10000','10000'],
'G':['01111','10000','10000','10111','10001','10001','01111'],
'H':['10001','10001','10001','11111','10001','10001','10001'],
'I':['111','010','010','010','010','010','111'],
'J':['00111','00010','00010','00010','10010','10010','01100'],
'K':['10001','10010','10100','11000','10100','10010','10001'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
'M':['10001','11011','10101','10101','10001','10001','10001'],
'N':['10001','11001','11001','10101','10011','10011','10001'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'P':['11110','10001','10001','11110','10000','10000','10000'],
'Q':['01110','10001','10001','10001','10101','10010','01101'],
'R':['11110','10001','10001','11110','10100','10010','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'U':['10001','10001','10001','10001','10001','10001','01110'],
'V':['10001','10001','10001','10001','10001','01010','00100'],
'W':['10001','10001','10001','10101','10101','11011','10001'],
'X':['10001','10001','01010','00100','01010','10001','10001'],
'Y':['10001','10001','01010','00100','00100','00100','00100'],
'Z':['11111','00001','00010','00100','01000','10000','11111'],
'0':['01110','10001','10011','10101','11001','10001','01110'],
'1':['010','110','010','010','010','010','111'],
'2':['01110','10001','00001','00010','00100','01000','11111'],
'3':['11110','00001','00001','01110','00001','00001','11110'],
'4':['00010','00110','01010','10010','11111','00010','00010'],
'5':['11111','10000','10000','11110','00001','00001','11110'],
'6':['01110','10000','10000','11110','10001','10001','01110'],
'7':['11111','00001','00010','00100','01000','01000','01000'],
'8':['01110','10001','10001','01110','10001','10001','01110'],
'9':['01110','10001','10001','01111','00001','00001','01110'],
'-':['000','000','000','111','000','000','000'],
'.':['0','0','0','0','0','1','1'],
'/':['00001','00001','00010','00100','01000','10000','10000'],
'+':['00000','00100','00100','11111','00100','00100','00000'],
' ':['000']*7,
}
def textbits(text,x,y,height=1.4):
 cell=height/7;out=[]
 for ch in text.upper():
  glyph=FONT.get(ch,FONT[' ']);cols=len(glyph[0])
  for row,s in enumerate(glyph):
   for col,v in enumerate(s):
    if v=='1':out.append(box(x+col*cell,y+row*cell,x+(col+1)*cell,y+(row+1)*cell))
  x+=(cols+1)*cell
 return unary_union(out)

def silktext(txt,x,y,h=1.4):silks.append(dict(type='text',text=txt,x=x,y=y,height=h))
def silkline(ps,width=.15):silks.append(dict(type='line',points=ps,width=width))
silktext('DUAL LR2021',8,7,2.1);silktext('REV A / PROTOTYPE',8,10.3,1.4)
silktext('USB-C',46,0.7,1.4)
silktext('RADIO A',10.2,39.2,1.4);silktext('RADIO B',75.,39.2,1.4)
silktext('ANT',2.,39.5,1.4);silktext('ANT',94.,39.5,1.4)
silktext('3V3 ONLY / POWER OFF TO INSERT',19.,61.5,1.4)
silktext('USB AND ANTENNAS STAY ON MODULES',17.,65.,1.4)
# Safe orientation markings: radio shield side faces up; MCU USB points toward y=0.
for x,y,sgn in [(18.,42.4,-1),(82.,42.4,1)]:
 silkline([(x,y),(x+sgn*5,y)]);silkline([(x+sgn*3.8,y-1),(x+sgn*5,y),(x+sgn*3.8,y+1)])
for c in components:
 if c['ref'].startswith('J'):
  ps=c['pads'];p0,p1=ps[0],ps[-1]
  # socket body envelope and first-pad marker, not module outline
  body=Polygon([(c['x']+rot(dx,dy,c['angle'])[0],c['y']+rot(dx,dy,c['angle'])[1]) for dx,dy in [(-1.205,-1.525),(1.205,-1.525),(1.205,2.54*(len(ps)-1)+1.525),(-1.205,2.54*(len(ps)-1)+1.525)]])
  silks.append(dict(type='polyline',points=list(body.exterior.coords),width=.12))
  # place identifiers independently to avoid obscuring connector pads
 elif c['kind']=='smd':
  silktext(c['ref'],c['x']-1.2,c['y']-1.9,1.05)
# connector references away from copper holes
for r,x,y in [('J1',37,1.6),('J2',61,1.6),('J3',28.5,48.),('J4',28.5,32.8),('J5',68,32.8),('J6',68,49.9)]:silktext(r,x,y,1.05)
for c in components:
 if c['kind']=='testpoint':silktext(c['ref'],c['x']-1.0,c['y']+1.15,.98)

# Clip silkscreen away from all mask openings (including test points) by 0.15 mm.
silk_geoms=[]
for s in silks:
 if s['type']=='text':g=textbits(s['text'],s['x'],s['y'],s['height'])
 else:g=LineString(s['points']).buffer(s['width']/2,quad_segs=4)
 silk_geoms.append(g)
mask_clear=unary_union([padshape(p,.05+.15) for p in pads]+[Point(h['x'],h['y']).buffer(h['drill']/2+.15) for h in holes])
silk_geom=unary_union(silk_geoms).difference(mask_clear).intersection(box(.3,.3,W-.3,H-.3))

# Data model is included so an independent program can audit every point and connection.
model=dict(name='Dual_LR2021_Carrier',revision='A',release_status='ENGINEERING REVIEW REQUIRED - NOT RELEASED',width=W,height=H,clearance=CLEAR,layers=LAYERS,components=components,pads=pads,tracks=tracks,vias=vias,holes=holes,keepouts=keepouts,silks=silks)
(ROOT/'source'/'design_model.json').write_text(json.dumps(model,indent=2))

# Verify copper geometry: different-net clearance, NPTH clearance, board edge, all-net connectivity.
items=defaultdict(list)
for p in pads:
 for l in layers_for(p):items[l].append((p['net'],f'{p["ref"]}.{p["num"]}',padshape(p)))
for i,t in enumerate(tracks):items[t['layer']].append((t['net'],f'track{i}',geom_item(t)))
for i,v in enumerate(vias):
 for l in LAYERS:items[l].append((v['net'],f'via{i}',viashape(v)))
for l,pl in planes.items():
 for j,po in enumerate(polygons(pl)):items[l].append(('GND',f'plane{j}',po))
viol=[];min_clear=1e9
from shapely.strtree import STRtree
for l,its in items.items():
 gs=[i[2] for i in its];tree=STRtree(gs)
 for i,(n,name,g) in enumerate(its):
  for j in tree.query(g.buffer(CLEAR+.001)):
   if j<=i or its[j][0]==n:continue
   d=g.distance(gs[j]);min_clear=min(min_clear,d)
   if d<CLEAR-1e-5:viol.append(dict(type='copper_clearance',layer=l,a=name,b=its[j][1],net_a=n,net_b=its[j][0],distance=rnd(d)))
  if not box(.25,.25,W-.25,H-.25).covers(g):viol.append(dict(type='board_edge',layer=l,item=name))
  for h in holes:
   if g.distance(Point(h['x'],h['y']).buffer(h['drill']/2))<.25-1e-5:viol.append(dict(type='npth_clearance',layer=l,item=name,hole=h['ref']))

# Copper connectivity with layer bridging only at plated holes and vias.
netnames=sorted({p['net'] for p in pads if not p['net'].startswith('NC_')})
conn=[]
for n in netnames:
 nodes=[];layer_ids=defaultdict(list)
 for l,its in items.items():
  for nn,name,g in its:
   if nn==n:
    layer_ids[l].append(len(nodes));nodes.append((l,name,g))
 parent=list(range(len(nodes)))
 def root(k):
  while parent[k]!=k:parent[k]=parent[parent[k]];k=parent[k]
  return k
 def union(a,b):parent[root(a)]=root(b)
 for l,idx in layer_ids.items():
  for ii,a in enumerate(idx):
   for b in idx[ii+1:]:
    if nodes[a][2].distance(nodes[b][2])<1e-5:union(a,b)
 bridges=defaultdict(list)
 for i,(l,name,g) in enumerate(nodes):
  if name.startswith('via') or any(f'{p["ref"]}.{p["num"]}'==name and p['kind']=='thru_hole' for p in pads):bridges[name].append(i)
 for inds in bridges.values():
  for i in inds[1:]:union(inds[0],i)
 # Only terminal-bearing components matter; isolated plane islands are separately flagged.
 terminals=[]
 for i,(l,name,g) in enumerate(nodes):
  if any(f'{p["ref"]}.{p["num"]}'==name for p in pads):terminals.append(i)
 groups=defaultdict(list)
 for i in terminals:groups[root(i)].append(nodes[i][1])
 groups=[sorted(set(g)) for g in groups.values()]
 ok=len(groups)==1
 conn.append(dict(net=n,connected=ok,terminal_groups=groups))
 if not ok:viol.append(dict(type='unconnected',net=n,groups=groups))

report=dict(status='PASS' if not viol else 'FAIL',scope='Independent Python geometric clearance and copper connectivity checks only; native KiCad ERC/DRC and external CAM/DFM not run.',violations=viol,min_checked_clearance_mm=min_clear,net_connectivity=conn,counts=dict(components=len(components),pads=len(pads),routed_paths=len(tracks),vias=len(vias),holes=len(holes)),limitations=['Native KiCad import/ERC/DRC not executed','No physical fit, power, USB, RF, environmental or regulatory tests','Pin mapping derived from vendor underside photograph; independent top-view verification remains a release gate','No vendor acceptance, stock reservation, assembly quote or order'])
(ROOT/'verification'/'geometric_check.json').write_text(json.dumps(report,indent=2))
print('GEOMETRIC CHECK:',report['status'],'violations',len(viol),flush=True)
if viol:
 print(json.dumps(viol[:25],indent=2));sys.exit(2)

# RS-274X Gerber positive copper/mask layers. Coordinates: mm; origin lower-left.
class Gerber:
 def __init__(self,name,attribute):
  self.name=name;self.lines=['G04 Dual LR2021 carrier Rev A - ENGINEERING REVIEW REQUIRED*','%FSLAX46Y46*%','%MOMM*%','%LPD*%',f'%TF.FileFunction,{attribute}*%','G01*'];self.ap={};self.ops=[]
 def aperture(self,shape,*sizes):
  key=(shape,)+tuple(round(v,6) for v in sizes)
  if key not in self.ap:self.ap[key]=10+len(self.ap)
  return self.ap[key]
 def xy(self,x,y):return f'X{int(round(x*1e6))}Y{int(round((H-y)*1e6))}'
 def flash(self,p,extra=0):
  if p['shape']=='circle':d=self.aperture('C',p['sx']+2*extra)
  else:
   sx,sy=p['sx']+2*extra,p['sy']+2*extra
   if int(round(p['angle']))%180==90:sx,sy=sy,sx
   d=self.aperture('R',sx,sy)
  self.ops += [f'D{d}*',self.xy(p['x'],p['y'])+'D03*']
 def line(self,points,width):
  d=self.aperture('C',width);self.ops.append(f'D{d}*')
  for i,(x,y) in enumerate(points):self.ops.append(self.xy(x,y)+('D02*' if i==0 else 'D01*'))
 def poly(self,poly):
  if poly.is_empty:return
  # Emit polygonal regions; hole polarity handled within isolated geometry blocks.
  for po in polygons(poly):
   self.ops.append('G36*')
   for i,(x,y) in enumerate(po.exterior.coords):self.ops.append(self.xy(x,y)+('D02*' if i==0 else 'D01*'))
   self.ops.append('G37*')
   for ring in po.interiors:
    self.ops += ['%LPC*%','G36*']
    for i,(x,y) in enumerate(ring.coords):self.ops.append(self.xy(x,y)+('D02*' if i==0 else 'D01*'))
    self.ops+=['G37*','%LPD*%']
 def save(self,path):
  if not self.ap:self.aperture('C',.1)
  defs=[f'%ADD{n}{k[0]},'+('X'.join(f'{v:.6f}' for v in k[1:]))+'*%' for k,n in self.ap.items()]
  Path(path).write_text('\n'.join(self.lines+defs+[f'D{min(self.ap.values())}*']+self.ops+['M02*','']))

gdir=ROOT/'manufacturing'/'gerbers'
for i,l in enumerate(LAYERS):
 g=Gerber(l,f'Copper,L{i+1},'+('Top' if i==0 else 'Bot' if i==3 else 'Inr'))
 if l in planes:g.poly(planes[l])
 for t in tracks:
  if t['layer']==l:g.line(t['points'],t['width'])
 for p in pads:
  if l in layers_for(p):g.flash(p)
 for v in vias:g.flash(dict(x=v['x'],y=v['y'],shape='circle',sx=v['diameter'],sy=v['diameter'],angle=0))
 g.save(gdir/f'Dual_LR2021-RevA-{l.replace(".","_")}.gbr')
for side in ['F','B']:
 g=Gerber(side+'.Mask','Soldermask,'+('Top' if side=='F' else 'Bot'))
 for p in pads:
  if side=='F' or p['kind']=='thru_hole':g.flash(p,.05)
 # Vias deliberately tented. NPTH holes drill through mask.
 g.save(gdir/f'Dual_LR2021-RevA-{side}_Mask.gbr')
g=Gerber('F.Paste','Paste,Top')
for p in pads:
 if p['kind']=='smd' and next(c for c in components if c['ref']==p['ref'])['kind']=='smd':g.flash(p)
g.save(gdir/'Dual_LR2021-RevA-F_Paste.gbr')
g=Gerber('F.SilkS','Legend,Top');g.poly(silk_geom);g.save(gdir/'Dual_LR2021-RevA-F_SilkS.gbr')
g=Gerber('Edge.Cuts','Profile,NP');g.line([(0,0),(W,0),(W,H),(0,H),(0,0)],.05);g.save(gdir/'Dual_LR2021-RevA-Edge_Cuts.gbr')

for plated in [True,False]:
 ds=[]
 if plated:
  ds=[(p['drill'],p['x'],p['y']) for p in pads if p['kind']=='thru_hole']+[(v['drill'],v['x'],v['y']) for v in vias]
 else:ds=[(h['drill'],h['x'],h['y']) for h in holes]
 dia=sorted(set(d[0] for d in ds));lines=['M48',';FILE_FORMAT=3:3',';TYPE='+('PLATED' if plated else 'NON_PLATED'),'METRIC,LZ']
 lines += [f'T{i+1:02d}C{d:.3f}' for i,d in enumerate(dia)];lines += ['%','G90','G05']
 for i,d in enumerate(dia):
  lines.append(f'T{i+1:02d}')
  for dd,x,y in ds:
   if dd==d:lines.append(f'X{x:.3f}Y{H-y:.3f}')
 lines+=['M30',''];(gdir/f'Dual_LR2021-RevA-{"PTH" if plated else "NPTH"}.drl').write_text('\n'.join(lines))

# Native board format. All footprints embedded; project library provided below.
netid={n:i+1 for i,n in enumerate(sorted({p['net'] for p in pads}))}
# Real no-connects keep unique net names in this generated board for independent audit.
proj='Dual_LR2021_Carrier'
board=['(kicad_pcb (version 20221018) (generator dual_lr2021_generator)',
 '(general (thickness 1.6))','(paper "A4")',
 '(title_block (title "Dual LR2021 Socketed Carrier") (date "2026-10-13") (rev "A") (company "Lane Araujo") (comment 1 "ENGINEERING REVIEW REQUIRED - NOT RELEASED"))',
 '(layers (0 "F.Cu" signal) (1 "In1.Cu" power "GND") (2 "In2.Cu" signal) (31 "B.Cu" signal) (32 "B.Adhes" user "B.Adhesive") (33 "F.Adhes" user "F.Adhesive") (34 "B.Paste" user) (35 "F.Paste" user) (36 "B.SilkS" user "B.Silkscreen") (37 "F.SilkS" user "F.Silkscreen") (38 "B.Mask" user) (39 "F.Mask" user) (40 "Dwgs.User" user "User.Drawings") (41 "Cmts.User" user "User.Comments") (44 "Edge.Cuts" user) (46 "B.CrtYd" user "B.Courtyard") (47 "F.CrtYd" user "F.Courtyard") (48 "B.Fab" user) (49 "F.Fab" user))',
 '(setup (pad_to_mask_clearance 0.05) (solder_mask_min_width 0.10) (aux_axis_origin 0 70) (grid_origin 0 0))','(net 0 "")']
board += [f'(net {i} {q(n)})' for n,i in netid.items()]
fpdir=ROOT/'source'/'Carrier.pretty';fpdir.mkdir(exist_ok=True)

def footprint_text(c,standalone=False):
 fs=[f'(footprint {q(c["footprint"] if standalone else "Carrier:"+c["footprint"])} '+('(version 20221018) (generator dual_lr2021_generator) ' if standalone else '')+'(layer "F.Cu")']
 if not standalone:fs+=[f'(tstamp {uid("footprint/"+c["ref"])})',f'(at {c["x"]} {c["y"]} {c["angle"]})',f'(path "/{uid("root")}/{c["uuid"]}")']
 fs += [f'(descr {q(c["description"])})',f'(attr {"through_hole" if c["kind"]=="through_hole" else "smd exclude_from_pos_files exclude_from_bom" if c["kind"]=="testpoint" else "smd"})',f'(fp_text reference {q("REF**" if standalone else c["ref"])} (at 0 -2) (layer "F.SilkS") hide (effects (font (size 1 1) (thickness 0.15))))',f'(fp_text value {q(c["value"])} (at 0 2) (layer "F.Fab") hide (effects (font (size 1 1) (thickness 0.15))))']
 if c['kind']=='through_hole':
  bx,by=1.205,2.54*(len(c['pads'])-1)+1.525
  fs.append(f'(fp_rect (start {-bx} -1.525) (end {bx} {by}) (stroke (width 0.10) (type default)) (fill none) (layer "F.Fab"))')
  fs.append(f'(fp_rect (start {-bx-.25} -1.775) (end {bx+.25} {by+.25}) (stroke (width 0.05) (type default)) (fill none) (layer "F.CrtYd"))')
 elif c['kind']=='smd':
  bx,by=(1.05,.625) if c['ref'][0] in 'RC' else (.65,1.05)
  fs.append(f'(fp_rect (start {-bx} {-by}) (end {bx} {by}) (stroke (width 0.10) (type default)) (fill none) (layer "F.Fab"))')
  fs.append('(fp_rect (start -1.85 -1.35) (end 1.85 1.35) (stroke (width 0.05) (type default)) (fill none) (layer "F.CrtYd"))')
 for p in c['pads']:
  la='"*.Cu" "*.Mask"' if p['kind']=='thru_hole' else '"F.Cu" "F.Mask"'+(' "F.Paste"' if c['kind']=='smd' else '')
  drill=f'(drill {p["drill"]})' if p['drill'] else ''
  ns=f'(net {netid[p["net"]]} {q(p["net"])})' if not standalone else ''
  fs.append(f'(pad {q(p["num"])} {p["kind"]} {p["shape"]} (at {p["local_x"]} {p["local_y"]}) (size {p["sx"]} {p["sy"]}) {drill} (layers {la}) {ns})')
 fs.append(')');return '\n'.join(fs)
for c in components:
 board.append(footprint_text(c))
 fp=fpdir/(c['footprint']+'.kicad_mod')
 fp.write_text(footprint_text(c,True))
for h in holes:
 board.append(f'(footprint "Carrier:MountingHole_3.2" (layer "F.Cu") (at {h["x"]} {h["y"]}) (attr board_only exclude_from_pos_files exclude_from_bom) (fp_text reference {q(h["ref"])} (at 0 -3) (layer "F.Fab") (effects (font (size 1 1) (thickness 0.15)))) (fp_text value "M3 NPTH" (at 0 3) (layer "F.Fab") hide (effects (font (size 1 1) (thickness 0.15)))) (pad "" np_thru_hole circle (at 0 0) (size 3.2 3.2) (drill 3.2) (layers "*.Cu" "*.Mask")))')
for i,t in enumerate(tracks):
 for j,(a,b) in enumerate(zip(t['points'],t['points'][1:])):board.append(f'(segment (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (width {t["width"]}) (layer {q(t["layer"])}) (net {netid[t["net"]]}) (tstamp {uid(f"track/{i}/{j}")}))')
for i,v in enumerate(vias):board.append(f'(via (at {v["x"]} {v["y"]}) (size {v["diameter"]}) (drill {v["drill"]}) (layers "F.Cu" "B.Cu") (net {netid[v["net"]]}) (tstamp {uid("via/"+str(i))}))')
for a,b in zip([(0,0),(W,0),(W,H),(0,H)],[(W,0),(W,H),(0,H),(0,0)]):board.append(f'(gr_line (start {a[0]} {a[1]}) (end {b[0]} {b[1]}) (stroke (width 0.05) (type default)) (layer "Edge.Cuts"))')
# Polygon triangulation stores the exact same filled copper as the neutral Gerbers.
for l,pl in planes.items():
 z=[f'(zone (net {netid["GND"]}) (net_name "GND") (layer {q(l)}) (tstamp {uid("zone/"+l)}) (hatch edge 0.5) (connect_pads (clearance 0.25)) (min_thickness 0.20) (filled_areas_thickness no) (fill yes (thermal_gap 0.30) (thermal_bridge_width 0.30)) (polygon (pts (xy 0.4 0.4) (xy 99.6 0.4) (xy 99.6 69.6) (xy 0.4 69.6)))']
 tris=constrained_delaunay_triangles(pl)
 for po in tris.geoms:
  coords=list(po.exterior.coords)[:-1]
  z.append(f'(filled_polygon (layer {q(l)}) (pts '+' '.join(f'(xy {rnd(x)} {rnd(y)})' for x,y in coords)+'))')
 z.append(')');board.append('\n'.join(z))
for k in keepouts:
 pts=[(k['x']+k['r']*math.cos(a),k['y']+k['r']*math.sin(a)) for a in np.linspace(0,2*math.pi,48,endpoint=False)]
 board.append('(zone (net 0) (net_name "") (layers "*.Cu") (tstamp '+uid('keepout/'+str(k['x'])+'/'+str(k['y']))+') (hatch edge 0.5) (keepout (tracks not_allowed) (vias not_allowed) (pads allowed) (copperpour not_allowed) (footprints allowed)) (polygon (pts '+' '.join(f'(xy {rnd(x)} {rnd(y)})' for x,y in pts)+')))')
# Exact clipped silkscreen polygon triangles. Original readable text retained on User.Drawings.
for po in constrained_delaunay_triangles(silk_geom).geoms:
 board.append('(gr_poly (pts '+' '.join(f'(xy {rnd(x)} {rnd(y)})' for x,y in list(po.exterior.coords)[:-1])+') (stroke (width 0) (type default)) (fill solid) (layer "F.SilkS"))')
for s in silks:
 if s['type']=='text':board.append(f'(gr_text {q(s["text"])} (at {s["x"]} {s["y"]}) (layer "Dwgs.User") (effects (font (size {s["height"]} {s["height"]}) (thickness 0.15)) (justify left top)))')
board.append(')');(ROOT/'source'/f'{proj}.kicad_pcb').write_text('\n'.join(board))
(ROOT/'source'/'fp-lib-table').write_text('(fp_lib_table\n (lib (name "Carrier")(type "KiCad")(uri "${KIPRJMOD}/Carrier.pretty")(options "")(descr "Custom datasheet-derived prototype footprints; independent review required"))\n)\n')
(ROOT/'source'/f'{proj}.kicad_pro').write_text(json.dumps({'meta':{'filename':proj+'.kicad_pro','version':1},'board':{'design_settings':{'rules':{'min_clearance':.2,'min_track_width':.2,'min_via_diameter':.6,'min_through_hole_diameter':.3,'min_hole_clearance':.25,'min_copper_edge_clearance':.25}}},'net_settings':{'classes':[{'name':'Default','clearance':.2,'track_width':.2,'via_diameter':.6,'via_drill':.3,'microvia_diameter':.3,'microvia_drill':.1,'diff_pair_width':.2,'diff_pair_gap':.25}]}} ,indent=2))
# Save WKT plane/silk geometry for independent export validation and exact drawing previews.
(ROOT/'source'/'planes.json').write_text(json.dumps({l:p.wkt for l,p in planes.items()}))
(ROOT/'source'/'silkscreen.wkt').write_text(silk_geom.wkt)
print('Exports complete',flush=True)
