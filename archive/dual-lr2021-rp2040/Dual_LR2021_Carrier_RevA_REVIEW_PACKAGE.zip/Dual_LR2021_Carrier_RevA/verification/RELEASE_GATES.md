# Unclosed release gates

- [ ] Independent electrical review of complete schematic and actual module revisions.
- [ ] Radio top-view contact mapping verified against actual pre-headered HF-M module, not only the underside photo. Verify RF header-pad connection/jumper state and any socket-stub effect.
- [ ] Samtec sockets physically mate to actual header tails and seated modules clear carrier parts.
- [ ] Controller regulator revision, USB input policy, current budget and thermal behavior verified.
- [ ] Native KiCad import, library consistency, ERC, refill, DRC and netlist comparison performed.
- [ ] Independent CAM viewer/DFM review of every copper/mask/paste/drill layer.
- [ ] Assembly provider confirms all six female sockets, THT process, component rotations and procurement.
- [ ] All component sourcing and any substitutes resolved with approved exact MPNs.
- [ ] First article: unpowered checks, controlled power, GPIO/USB/radio-driver test, both radios independently.
- [ ] Coexistence/desensitization and desired throughput measured, not assumed.

Custom geometry and export checks are NOT native CAD/ERC/DRC, certification or first-article results.
