# Dual LR2021 Socketed Carrier - Rev A

## ENGINEERING REVIEW REQUIRED - NOT RELEASED FOR BLIND ORDERING

This is an actual generated prototype design package, not a tested or independently approved production release. Fabrication and assembly files are provided for review and quotation. Native KiCad import/ERC/DRC and physical fit/electrical/RF tests could not be run here. Do not treat a geometric PASS as proof that a manufactured system will work.

## Start here

1. Open `docs/Engineering_and_Order_Packet.pdf` and `assembly/assembly_drawing.pdf`.
2. Confirm the exact module choice: 2 x Waveshare Core2021-HF-M (34523), 1 x Waveshare RP2040-Plus-M 4MB (20808), all pre-headered. The sockets are NOT generic to all LR2021 or RP2040 boards.
3. Have a qualified reviewer close `verification/RELEASE_GATES.md` and run native KiCad and independent CAM checks.
4. Send the package with `assembly/RFQ_to_assembler.txt` to a full-service PCB ASSEMBLY supplier. Gerbers alone buy a bare board, not a finished carrier.

## No owner soldering

The factory solders all 20 SMT parts and all SIX female socket strips. Base delivery leaves only plugging in the pre-headered modules. For completely populated delivery, request the optional module procurement/insertion scope too. This package includes a pin map but NOT radio application firmware; assembled hardware is not the same as a working USB radio or mesh network.

## Files

- `source/`: KiCad board + schematic + embedded/local libraries, netlist and reproducible Python generator/model.
- `manufacturing/gerbers/`: four copper layers, mask, top paste, top silkscreen, profile and separate PTH/NPTH drills.
- `assembly/`: carrier BOM, SMT/THT/all placement lists, optional module BOM, assembly drawing and RFQ.
- `docs/`: electrical schematic PDF, layer views, exact terminal map, source register and engineering packet.
- `verification/`: custom geometric/export readback results and the outstanding release gates.
- `firmware/`: pin allocation and software requirements only.

## Procurement

The BOM contains exact MPNs, including TDK CGA4J3X5R1A106K125AB for the 10uF bulk capacitors. All part availability, module revisions and any proposed substitutes require confirmation at quote time. There are no fabricated supplier IDs, stock reservations or accepted quotes in this package.

## Reproduction

Install `source/requirements.txt`, then run `python source/build_design.py` (cached routing) and `python source/build_package.py`. Run `python source/check_exports.py` for export verification. Use `--reroute` on build_design.py if placement/connectivity changes. Never reuse cached routing after moving pads. Generator changes require regenerating and rechecking the entire package.

Board/net geometry was created programmatically, not exported by native KiCad. Exact filled plane polygons are included as a snapshot; a native refill may change geometry. After native review, regenerate the full manufacturing package from the reviewed project rather than mixing exports.
