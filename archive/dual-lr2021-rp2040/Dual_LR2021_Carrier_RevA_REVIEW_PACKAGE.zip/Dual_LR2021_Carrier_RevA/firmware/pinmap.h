#pragma once
/* Dual LR2021 Carrier Rev A. Pin mapping only, NOT an application/driver.
 * GPIO numbers below are RP2040 GPIOs, NOT physical socket numbers.
 * Both radios default OFF. Prevent GPIO back-powering before disabling EN.
 */
#define RADIO_A_SPI_INSTANCE 1
#define RADIO_A_MISO_GPIO 8
#define RADIO_A_CS_GPIO 9
#define RADIO_A_SCK_GPIO 10
#define RADIO_A_MOSI_GPIO 11
#define RADIO_A_BUSY_GPIO 12
#define RADIO_A_IRQ_GPIO 13
#define RADIO_A_RESET_GPIO 14
#define RADIO_A_POWER_EN_GPIO 6
#define RADIO_B_SPI_INSTANCE 0
#define RADIO_B_MISO_GPIO 16
#define RADIO_B_CS_GPIO 17
#define RADIO_B_SCK_GPIO 18
#define RADIO_B_MOSI_GPIO 19
#define RADIO_B_BUSY_GPIO 20
#define RADIO_B_IRQ_GPIO 21
#define RADIO_B_RESET_GPIO 22
#define RADIO_B_POWER_EN_GPIO 26
