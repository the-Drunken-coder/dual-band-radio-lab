# Firmware scope

Only a reviewed-against-model pin allocation is included. There is NO completed radio driver, USB modem firmware, mesh stack, UF2, or physical test claim.

Use the vendor-supported LR2021 driver and verify SPI pin multiplexing against the actual RP2040 SDK. Radio A uses SPI1; B uses SPI0. EN is active high; both EN lines have external 100k pull-downs. All module-facing outputs must be high-impedance with no pull-ups while that module is off. USB power budgeting/enumeration/suspend must be handled before switching on extra loads. See the engineering packet for the full bring-up contract.

Do not assume stock single-radio firmware knows about these power enables or pin assignments.
